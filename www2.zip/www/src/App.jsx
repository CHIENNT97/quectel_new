import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { useState, useEffect, createContext } from 'react'
import Layout from './components/Layout/Layout'
import Dashboard from './pages/Dashboard'
import Network from './pages/Network'
import Scanner from './pages/Scanner'
import Settings from './pages/Settings'
import SMS from './pages/SMS'
import DeviceInfo from './pages/DeviceInfo'

export const ThemeContext = createContext()

function App() {
    const [theme, setTheme] = useState(() => {
        return localStorage.getItem('theme') || 'dark'
    })

    useEffect(() => {
        document.documentElement.setAttribute('data-theme', theme)
        localStorage.setItem('theme', theme)
    }, [theme])

    const toggleTheme = () => {
        setTheme(prev => prev === 'dark' ? 'light' : 'dark')
    }

    return (
        <ThemeContext.Provider value={{ theme, toggleTheme }}>
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<Layout />}>
                        <Route index element={<Dashboard />} />
                        <Route path="network" element={<Network />} />
                        <Route path="scanner" element={<Scanner />} />
                        <Route path="settings" element={<Settings />} />
                        <Route path="sms" element={<SMS />} />
                        <Route path="deviceinfo" element={<DeviceInfo />} />
                    </Route>
                </Routes>
            </BrowserRouter>
        </ThemeContext.Provider>
    )
}

export default App
