import { useState, useEffect, useCallback } from 'react'

export function useATCommand() {
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState(null)

    const sendCommand = useCallback(async (command) => {
        setLoading(true)
        setError(null)

        try {
            const encodedCmd = encodeURIComponent(command)
            const response = await fetch(`/cgi-bin/get_atcommand?atcmd=${encodedCmd}`)

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`)
            }

            const data = await response.text()
            return data
        } catch (err) {
            setError(err.message)
            throw err
        } finally {
            setLoading(false)
        }
    }, [])

    return { sendCommand, loading, error }
}

export function useDashboardData(refreshRate = 5) {
    const [data, setData] = useState({
        temperature: '0',
        simStatus: 'Đang tải...',
        signalPercentage: '0',
        internetConnectionStatus: 'Đang tải...',
        activeSim: '-',
        networkProvider: '-',
        mccmnc: '-',
        apn: '-',
        networkMode: '-',
        bands: '-',
        bandwidth: '-',
        earfcns: '-',
        pccPCI: '-',
        sccPCI: '-',
        ipv4: '-',
        ipv6: '-',
        uptime: '-',
        signalAssessment: '-',
        downloadStat: '0',
        uploadStat: '0',
        csq: '-',
        cellID: '-',
        eNBID: '-',
        tac: '-',
        rsrpLTE: '-',
        rsrpNR: '-',
        rsrpLTEPercentage: 0,
        rsrpNRPercentage: 0,
        rsrqLTE: '-',
        rsrqNR: '-',
        rsrqLTEPercentage: 0,
        rsrqNRPercentage: 0,
        sinrLTE: '-',
        sinrNR: '-',
        sinrLTEPercentage: 0,
        sinrNRPercentage: 0,
        lastUpdate: new Date().toLocaleString('vi-VN'),
    })
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState(null)

    const fetchData = useCallback(async () => {
        const atcmd = 'AT+QTEMP;+QUIMSLOT?;+QSPN;+CGCONTRDP=1;+QMAP="WWANIP";+QENG="servingcell";+QCAINFO;+QSIMSTAT?;+CSQ;+QGDNRCNT?;+QGDCNT?'

        try {
            const response = await fetch(`/cgi-bin/get_atcommand?atcmd=${encodeURIComponent(atcmd)}`)
            const rawdata = await response.text()

            if (rawdata.includes('ERROR')) {
                setError('Lỗi khi lấy dữ liệu')
                return
            }

            const lines = rawdata.split('\n')
            const newData = { ...data }

            // Parse Temperature
            try {
                const tempLine = lines.find(line => line.includes('+QTEMP:"cpuss-0-usr"'))
                if (tempLine) {
                    newData.temperature = tempLine.split(',')[1].replace(/"/g, '')
                } else {
                    const tempLine2 = lines.find(line => line.includes('+QTEMP:"cpu0-a7-usr"'))
                    if (tempLine2) {
                        newData.temperature = tempLine2.split(',')[1].replace(/"/g, '')
                    }
                }
            } catch (e) { }

            // Parse SIM Status
            try {
                const simLine = lines.find(line => line.includes('+QSIMSTAT:'))
                if (simLine) {
                    const simStatus = simLine.split(' ')[1].split(',')[1]
                    newData.simStatus = simStatus === '1' ? 'Hoạt động' : 'Không có SIM'
                }
            } catch (e) { }

            // Parse Active SIM
            try {
                const slotLine = lines.find(line => line.includes('+QUIMSLOT:'))
                if (slotLine) {
                    const slot = slotLine.split(' ')[1].trim()
                    newData.activeSim = `SIM ${slot}`
                }
            } catch (e) { }

            // Parse Network Provider
            try {
                const spnLine = lines.find(line => line.includes('+QSPN:'))
                if (spnLine) {
                    const parts = spnLine.split(',')
                    let provider = parts[0].replace('+QSPN: ', '').replace(/"/g, '').replace(/ /g, '')
                    if (/^[0-9]+$/.test(provider)) {
                        provider = parts[2].replace(/"/g, '')
                    }
                    newData.networkProvider = provider
                    newData.mccmnc = parts[4].replace(/"/g, '')
                }
            } catch (e) { }

            // Parse APN
            try {
                const apnLine = lines.find(line => line.includes('+CGCONTRDP:'))
                if (apnLine) {
                    newData.apn = apnLine.split(',')[2].replace(/"/g, '')
                }
            } catch (e) { }

            // Parse Network Mode and Signal
            try {
                const servingLine = lines.find(line => line.includes('+QENG: "servingcell"'))
                if (servingLine) {
                    const parts = servingLine.split(',')
                    const networkMode = parts[2].replace(/"/g, '')
                    const duplexMode = parts[3].replace(/"/g, '')

                    if (networkMode === 'NR5G-SA') {
                        newData.networkMode = `5G SA ${duplexMode}`
                        newData.internetConnectionStatus = 'Đã kết nối'
                    } else if (networkMode === 'LTE') {
                        newData.networkMode = `4G LTE ${duplexMode}`
                        newData.internetConnectionStatus = 'Đã kết nối'
                    }
                }
            } catch (e) { }

            // Parse Signal Quality (CSQ)
            try {
                const csqLine = lines.find(line => line.includes('+CSQ:'))
                if (csqLine) {
                    const csqParts = csqLine.split(':')[1].split(',')
                    const csqValue = parseInt(csqParts[0].trim())
                    if (csqValue !== 99) {
                        newData.csq = `${csqValue} (${Math.round((csqValue / 31) * 100)}%)`
                        newData.signalPercentage = Math.round((csqValue / 31) * 100).toString()

                        // Signal Assessment
                        const pct = (csqValue / 31) * 100
                        if (pct >= 70) newData.signalAssessment = 'Tuyệt vời'
                        else if (pct >= 50) newData.signalAssessment = 'Tốt'
                        else if (pct >= 30) newData.signalAssessment = 'Trung bình'
                        else newData.signalAssessment = 'Yếu'
                    }
                }
            } catch (e) { }

            // Parse CA Info for bands
            try {
                const caLines = lines.filter(line => line.includes('+QCAINFO:'))
                if (caLines.length > 0) {
                    const bands = caLines.map(line => {
                        const match = line.match(/LTE BAND (\d+)|NR5G BAND (\d+)/)
                        if (match) return `B${match[1] || match[2]}`
                        return null
                    }).filter(Boolean)
                    if (bands.length > 0) {
                        newData.bands = bands.join(' + ')
                    }
                }
            } catch (e) { }

            // Parse uptime
            try {
                const response2 = await fetch('/cgi-bin/get_uptime')
                const uptimeData = await response2.text()
                if (uptimeData) {
                    newData.uptime = uptimeData.trim()
                }
            } catch (e) { }

            newData.lastUpdate = new Date().toLocaleString('vi-VN')
            setData(newData)
            setError(null)
        } catch (err) {
            setError(err.message)
        } finally {
            setLoading(false)
        }
    }, [])

    useEffect(() => {
        fetchData()
        const interval = setInterval(fetchData, refreshRate * 1000)
        return () => clearInterval(interval)
    }, [fetchData, refreshRate])

    return { data, loading, error, refresh: fetchData }
}
