import { useContext } from 'react'
import { useLocation } from 'react-router-dom'
import { ThemeContext } from '../../App'

const pageTitles = {
    '/': 'Tổng quan',
    '/network': 'Cấu hình mạng',
    '/scanner': 'Quét sóng di động',
    '/settings': 'Cài đặt hệ thống',
    '/sms': 'Tin nhắn SMS',
    '/deviceinfo': 'Thông tin thiết bị',
}

function Header() {
    const { theme, toggleTheme } = useContext(ThemeContext)
    const location = useLocation()
    const title = pageTitles[location.pathname] || 'SimpleAdmin'

    return (
        <header className="header">
            <div className="header-left">
                <h1 className="page-title">{title}</h1>
            </div>
            <div className="header-right">
                <button
                    className="theme-toggle btn btn-icon btn-secondary"
                    onClick={toggleTheme}
                    title={theme === 'dark' ? 'Chế độ sáng' : 'Chế độ tối'}
                >
                    {theme === 'dark' ? '☀️' : '🌙'}
                </button>
            </div>
        </header>
    )
}

export default Header
