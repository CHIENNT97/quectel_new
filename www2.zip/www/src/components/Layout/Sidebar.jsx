import { NavLink, useLocation } from 'react-router-dom'
import { useState } from 'react'

const menuItems = [
    { path: '/', label: 'Trang chủ', icon: '🏠' },
    { path: '/network', label: 'Mạng', icon: '📶' },
    { path: '/scanner', label: 'Quét sóng', icon: '📡' },
    { path: '/settings', label: 'Cài đặt', icon: '⚙️' },
    { path: '/sms', label: 'Tin nhắn', icon: '💬' },
    { path: '/deviceinfo', label: 'Thiết bị', icon: 'ℹ️' },
]

function Sidebar() {
    const [collapsed, setCollapsed] = useState(false)
    const [mobileOpen, setMobileOpen] = useState(false)
    const location = useLocation()

    return (
        <>
            {/* Mobile overlay */}
            {mobileOpen && (
                <div
                    className="sidebar-overlay"
                    onClick={() => setMobileOpen(false)}
                />
            )}

            {/* Mobile toggle button */}
            <button
                className="mobile-menu-btn"
                onClick={() => setMobileOpen(!mobileOpen)}
            >
                <span className="hamburger">☰</span>
            </button>

            <aside className={`sidebar ${collapsed ? 'collapsed' : ''} ${mobileOpen ? 'mobile-open' : ''}`}>
                {/* Logo */}
                <div className="sidebar-header">
                    <div className="logo">
                        <span className="logo-icon">📱</span>
                        {!collapsed && <span className="logo-text">SimpleAdmin</span>}
                    </div>
                    <button
                        className="collapse-btn"
                        onClick={() => setCollapsed(!collapsed)}
                    >
                        {collapsed ? '→' : '←'}
                    </button>
                </div>

                {/* Navigation */}
                <nav className="sidebar-nav">
                    <ul>
                        {menuItems.map((item) => (
                            <li key={item.path}>
                                <NavLink
                                    to={item.path}
                                    className={({ isActive }) =>
                                        `nav-link ${isActive ? 'active' : ''}`
                                    }
                                    onClick={() => setMobileOpen(false)}
                                >
                                    <span className="nav-icon">{item.icon}</span>
                                    {!collapsed && <span className="nav-label">{item.label}</span>}
                                </NavLink>
                            </li>
                        ))}
                    </ul>
                </nav>

                {/* Console Link */}
                <div className="sidebar-footer">
                    <a
                        href="/console"
                        className="nav-link console-link"
                        target="_blank"
                        rel="noopener noreferrer"
                    >
                        <span className="nav-icon">🖥️</span>
                        {!collapsed && <span className="nav-label">Console</span>}
                    </a>
                </div>
            </aside>
        </>
    )
}

export default Sidebar
