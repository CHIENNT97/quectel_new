import { useState, useEffect, useCallback } from 'react'
import { useATCommand } from '../hooks/useATCommand'

function Settings() {
    const { sendCommand, loading } = useATCommand()
    const [atCommand, setAtCommand] = useState('')
    const [atResponse, setAtResponse] = useState('')
    const [showRebootModal, setShowRebootModal] = useState(false)
    const [isRebooting, setIsRebooting] = useState(false)
    const [countdown, setCountdown] = useState(0)

    // Settings state
    const [ttlEnabled, setTtlEnabled] = useState(false)
    const [ttlValue, setTtlValue] = useState('0')
    const [newTtl, setNewTtl] = useState('')
    const [ipPassStatus, setIpPassStatus] = useState(false)
    const [ipPassMode, setIpPassMode] = useState('')
    const [usbNetMode, setUsbNetMode] = useState('')
    const [currentUsbMode, setCurrentUsbMode] = useState('Unknown')
    const [dnsProxyStatus, setDnsProxyStatus] = useState(true)

    const fetchSettings = useCallback(async () => {
        try {
            // Fetch TTL status
            const ttlRes = await fetch('/cgi-bin/get_ttl_status')
            const ttlData = await ttlRes.json()
            setTtlEnabled(ttlData.isEnabled)
            setTtlValue(ttlData.ttl || '0')

            // Fetch other settings
            const data = await sendCommand('AT+QMAP="MPDN_RULE";+QMAP="DHCPV4DNS";+QCFG="usbnet"')
            const lines = data.split('\n')

            // IP Passthrough
            const ipLine = lines.find(l => l.includes('+QMAP: "MPDN_rule"'))
            if (ipLine && !ipLine.includes('0,0,0,0,0')) {
                setIpPassStatus(true)
            }

            // DNS Proxy
            const dnsLine = lines.find(l => l.includes('+QMAP: "DHCPV4DNS"'))
            if (dnsLine) {
                setDnsProxyStatus(dnsLine.includes('enable'))
            }

            // USB Net Mode
            const usbLine = lines.find(l => l.includes('+QCFG: "usbnet"'))
            if (usbLine) {
                const mode = usbLine.match(/(\d)/)?.[1]
                const modes = ['RMNET', 'ECM', 'MBIM', 'RNDIS']
                setCurrentUsbMode(modes[mode] || 'Unknown')
            }
        } catch (err) {
            console.error('Error fetching settings:', err)
        }
    }, [sendCommand])

    useEffect(() => {
        fetchSettings()
    }, [fetchSettings])

    const executeATCommand = async () => {
        if (!atCommand.trim()) {
            setAtCommand('ATI')
        }
        try {
            const result = await sendCommand(atCommand || 'ATI')
            setAtResponse(result)
        } catch (err) {
            setAtResponse(`Error: ${err.message}`)
        }
    }

    const reboot = async () => {
        setShowRebootModal(false)
        setIsRebooting(true)
        setCountdown(40)

        await sendCommand('AT+CFUN=1,1')

        const interval = setInterval(() => {
            setCountdown(prev => {
                if (prev <= 1) {
                    clearInterval(interval)
                    setIsRebooting(false)
                    window.location.reload()
                    return 0
                }
                return prev - 1
            })
        }, 1000)
    }

    const resetATSettings = async () => {
        await sendCommand('AT&F')
        setShowRebootModal(true)
    }

    const toggleIpPassthrough = async (enable) => {
        if (enable) {
            const cmd = ipPassMode === 'USB'
                ? 'AT+QMAP="MPDN_RULE",0,1,0,3,1,"FF:FF:FF:FF:FF:FF"'
                : 'AT+QMAP="MPDN_RULE",0,1,0,1,1,"FF:FF:FF:FF:FF:FF"'
            await sendCommand(cmd)
        } else {
            await sendCommand('AT+QMAP="MPDN_RULE",0;+QMAPWAC=1')
        }
        fetchSettings()
    }

    const toggleDnsProxy = async (enable) => {
        await sendCommand(`AT+QMAP="DHCPV4DNS","${enable ? 'enable' : 'disable'}"`)
        fetchSettings()
    }

    const changeUsbMode = async () => {
        const modes = { RMNET: 0, ECM: 1, MBIM: 2, RNDIS: 3 }
        await sendCommand(`AT+QCFG="usbnet",${modes[usbNetMode]}`)
        setShowRebootModal(true)
    }

    const updateTtl = async () => {
        await fetch(`/cgi-bin/set_ttl?ttlvalue=${newTtl}`)
        fetchSettings()
        setNewTtl('')
    }

    return (
        <div className="settings-page animate-fadeIn">
            {/* AT Terminal */}
            <div className="card">
                <div className="card-header">💻 AT Terminal</div>
                <div className="card-body">
                    <div className="form-group">
                        <textarea
                            className="form-control"
                            value={atResponse}
                            readOnly
                            style={{
                                height: '200px',
                                fontFamily: 'var(--font-mono)',
                                fontSize: '0.875rem',
                                background: 'var(--bg-secondary)'
                            }}
                            placeholder="Kết quả sẽ hiển thị ở đây..."
                        />
                    </div>
                    <div className="form-group">
                        <label className="form-label">Lệnh AT</label>
                        <div className="flex gap-sm">
                            <input
                                type="text"
                                className="form-control"
                                value={atCommand}
                                onChange={(e) => setAtCommand(e.target.value)}
                                placeholder="ATI"
                                onKeyDown={(e) => e.key === 'Enter' && executeATCommand()}
                            />
                            <button
                                className="btn btn-primary"
                                onClick={executeATCommand}
                                disabled={loading}
                            >
                                Gửi
                            </button>
                            <button
                                className="btn btn-secondary"
                                onClick={() => setAtResponse('')}
                            >
                                Xóa
                            </button>
                        </div>
                        <small style={{ color: 'var(--text-muted)' }}>
                            Phân cách nhiều lệnh bằng dấu chấm phẩy (;)
                        </small>
                    </div>
                </div>
            </div>

            <div className="grid grid-2" style={{ marginTop: 'var(--space-lg)' }}>
                {/* Quick Actions */}
                <div className="card">
                    <div className="card-header">⚡ Thao tác nhanh</div>
                    <div className="card-body">
                        <table>
                            <tbody>
                                <tr>
                                    <th>Khởi động lại</th>
                                    <td>
                                        <button
                                            className="btn btn-danger"
                                            onClick={() => setShowRebootModal(true)}
                                        >
                                            Khởi động lại
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <th>Đặt lại AT</th>
                                    <td>
                                        <button
                                            className="btn btn-warning"
                                            onClick={resetATSettings}
                                        >
                                            Đặt lại
                                        </button>
                                    </td>
                                </tr>
                                <tr>
                                    <th>IP Passthrough</th>
                                    <td>
                                        <div className="flex gap-sm items-center">
                                            <select
                                                className="form-control"
                                                value={ipPassMode}
                                                onChange={(e) => setIpPassMode(e.target.value)}
                                                style={{ width: 'auto' }}
                                            >
                                                <option value="">Chế độ...</option>
                                                <option value="ETH">ETH</option>
                                                <option value="USB">USB</option>
                                            </select>
                                            {ipPassStatus ? (
                                                <button
                                                    className="btn btn-danger"
                                                    onClick={() => toggleIpPassthrough(false)}
                                                >
                                                    Tắt
                                                </button>
                                            ) : (
                                                <button
                                                    className="btn btn-primary"
                                                    onClick={() => toggleIpPassthrough(true)}
                                                    disabled={!ipPassMode}
                                                >
                                                    Bật
                                                </button>
                                            )}
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <th>USB Protocol</th>
                                    <td>
                                        <div className="flex gap-sm items-center">
                                            <select
                                                className="form-control"
                                                value={usbNetMode}
                                                onChange={(e) => setUsbNetMode(e.target.value)}
                                                style={{ width: 'auto' }}
                                            >
                                                <option value="">{currentUsbMode}</option>
                                                <option value="RMNET">RMNET</option>
                                                <option value="ECM">ECM</option>
                                                <option value="MBIM">MBIM</option>
                                                <option value="RNDIS">RNDIS</option>
                                            </select>
                                            <button
                                                className="btn btn-primary"
                                                onClick={changeUsbMode}
                                                disabled={!usbNetMode}
                                            >
                                                Đổi
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <th>DNS Proxy</th>
                                    <td>
                                        <button
                                            className={`btn ${dnsProxyStatus ? 'btn-danger' : 'btn-primary'}`}
                                            onClick={() => toggleDnsProxy(!dnsProxyStatus)}
                                        >
                                            {dnsProxyStatus ? 'Tắt' : 'Bật'}
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                {/* TTL Settings */}
                <div className="card">
                    <div className="card-header">🔧 Cài đặt TTL</div>
                    <div className="card-body">
                        <div className="grid grid-2" style={{ marginBottom: 'var(--space-lg)' }}>
                            <div className={`status-box ${ttlEnabled ? 'active' : 'inactive'}`}>
                                {ttlEnabled ? '✅ TTL đang bật' : '❌ TTL đang tắt'}
                            </div>
                            <div className="status-box info">
                                Giá trị: {ttlValue}
                            </div>
                        </div>
                        <div className="form-group">
                            <input
                                type="number"
                                className="form-control"
                                placeholder="Nhập giá trị TTL (0 để tắt)"
                                value={newTtl}
                                onChange={(e) => setNewTtl(e.target.value)}
                            />
                            <small style={{ color: 'var(--text-muted)' }}>
                                Đặt TTL = 0 để tắt
                            </small>
                        </div>
                        <button
                            className="btn btn-primary"
                            onClick={updateTtl}
                            disabled={!newTtl}
                            style={{ width: '100%' }}
                        >
                            Cập nhật TTL
                        </button>
                    </div>
                </div>
            </div>

            {/* Reboot Confirmation Modal */}
            {showRebootModal && (
                <div className="modal-overlay">
                    <div className="modal">
                        <div className="modal-header">
                            <h3 className="modal-title">⚠️ Xác nhận khởi động lại</h3>
                        </div>
                        <div className="modal-body">
                            <p>Thiết bị sẽ được khởi động lại. Tiếp tục?</p>
                        </div>
                        <div className="modal-footer">
                            <button className="btn btn-secondary" onClick={() => setShowRebootModal(false)}>
                                Hủy
                            </button>
                            <button className="btn btn-danger" onClick={reboot}>
                                Khởi động lại
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Rebooting Modal */}
            {isRebooting && (
                <div className="modal-overlay">
                    <div className="modal">
                        <div className="flex flex-col items-center justify-center" style={{ padding: 'var(--space-xl)' }}>
                            <div className="spinner" style={{ marginBottom: 'var(--space-lg)' }}></div>
                            <h3>Đang khởi động lại...</h3>
                            <p style={{ color: 'var(--text-muted)' }}>Vui lòng chờ {countdown} giây</p>
                        </div>
                    </div>
                </div>
            )}

            <style>{`
        .status-box {
          padding: var(--space-md);
          border-radius: var(--radius-md);
          text-align: center;
          font-weight: 500;
        }
        .status-box.active {
          background: rgba(16, 185, 129, 0.1);
          color: var(--success);
          border: 1px solid var(--success);
        }
        .status-box.inactive {
          background: rgba(239, 68, 68, 0.1);
          color: var(--danger);
          border: 1px solid var(--danger);
        }
        .status-box.info {
          background: rgba(6, 182, 212, 0.1);
          color: var(--info);
          border: 1px solid var(--info);
        }
      `}</style>
        </div>
    )
}

export default Settings
