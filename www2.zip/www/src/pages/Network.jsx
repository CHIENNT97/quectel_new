import { useState, useEffect, useCallback } from 'react'
import { useATCommand } from '../hooks/useATCommand'

function Network() {
    const { sendCommand, loading } = useATCommand()
    const [showModal, setShowModal] = useState(false)
    const [countdown, setCountdown] = useState(0)
    const [networkMode, setNetworkMode] = useState('LTE')
    const [bands, setBands] = useState({ lte: [], nsa: [], sa: [] })
    const [lockedBands, setLockedBands] = useState({ lte: [], nsa: [], sa: [] })
    const [selectedBands, setSelectedBands] = useState([])
    const [activeBands, setActiveBands] = useState('-')

    // Network Settings
    const [apn, setApn] = useState('')
    const [newApn, setNewApn] = useState('')
    const [apnType, setApnType] = useState('')
    const [prefNetwork, setPrefNetwork] = useState('')
    const [nrMode, setNrMode] = useState('')
    const [currentSim, setCurrentSim] = useState('1')

    const fetchBands = useCallback(async () => {
        try {
            const data = await sendCommand('AT+QNWPREFCFG="policy_band"')
            const regex = /"([^"]+)",([0-9:]+)/g
            const parsed = {}
            let match
            while ((match = regex.exec(data)) !== null) {
                const type = match[1]
                const nums = match[2].split(':').map(Number)
                parsed[type] = nums
            }
            setBands({
                lte: parsed.lte_band || [],
                nsa: parsed.nsa_nr5g_band || [],
                sa: parsed.nr5g_band || []
            })

            // Get locked bands
            const lockedData = await sendCommand('AT+QNWPREFCFG="lte_band";+QNWPREFCFG="nsa_nr5g_band";+QNWPREFCFG="nr5g_band"')
            const lockedParsed = {}
            const regex2 = /"([^"]+)",([0-9:]+)/g
            while ((match = regex2.exec(lockedData)) !== null) {
                const type = match[1]
                const nums = match[2].split(':').map(Number)
                lockedParsed[type] = nums
            }
            setLockedBands({
                lte: lockedParsed.lte_band || [],
                nsa: lockedParsed.nsa_nr5g_band || [],
                sa: lockedParsed.nr5g_band || []
            })

            // Get current settings
            const settingsData = await sendCommand('AT+QUIMSLOT?;+CGCONTRDP=1;+QNWPREFCFG="mode_pref";+QCAINFO')
            const lines = settingsData.split('\n')

            // Parse SIM slot
            const simLine = lines.find(l => l.includes('+QUIMSLOT:'))
            if (simLine) setCurrentSim(simLine.split(':')[1].trim())

            // Parse APN
            const apnLine = lines.find(l => l.includes('+CGCONTRDP:'))
            if (apnLine) setApn(apnLine.split(',')[2]?.replace(/"/g, '') || '')

            // Parse active bands
            const caLines = lines.filter(l => l.includes('+QCAINFO:'))
            if (caLines.length > 0) {
                const activeBandList = caLines.map(l => {
                    const m = l.match(/LTE BAND (\d+)|NR5G BAND (\d+)/)
                    return m ? `B${m[1] || m[2]}` : null
                }).filter(Boolean)
                setActiveBands(activeBandList.join(' + ') || '-')
            }
        } catch (err) {
            console.error('Error fetching bands:', err)
        }
    }, [sendCommand])

    useEffect(() => {
        fetchBands()
    }, [fetchBands])

    const getCurrentBands = () => {
        switch (networkMode) {
            case 'NSA': return bands.nsa
            case 'SA': return bands.sa
            default: return bands.lte
        }
    }

    const getCurrentLockedBands = () => {
        switch (networkMode) {
            case 'NSA': return lockedBands.nsa
            case 'SA': return lockedBands.sa
            default: return lockedBands.lte
        }
    }

    const handleBandToggle = (band) => {
        setSelectedBands(prev =>
            prev.includes(band)
                ? prev.filter(b => b !== band)
                : [...prev, band]
        )
    }

    const lockBands = async () => {
        if (selectedBands.length === 0) return

        let cmd = ''
        const bandStr = selectedBands.join(':')
        switch (networkMode) {
            case 'NSA':
                cmd = `AT+QNWPREFCFG="nsa_nr5g_band",${bandStr}`
                break
            case 'SA':
                cmd = `AT+QNWPREFCFG="nr5g_band",${bandStr}`
                break
            default:
                cmd = `AT+QNWPREFCFG="lte_band",${bandStr}`
        }

        await sendCommand(cmd)
        showCountdown(3)
    }

    const resetBands = async () => {
        await sendCommand('AT+QNWPREFCFG="restore_band"')
        showCountdown(5)
    }

    const showCountdown = (seconds) => {
        setShowModal(true)
        setCountdown(seconds)
        const interval = setInterval(() => {
            setCountdown(prev => {
                if (prev <= 1) {
                    clearInterval(interval)
                    setShowModal(false)
                    fetchBands()
                    return 0
                }
                return prev - 1
            })
        }, 1000)
    }

    const saveSettings = async () => {
        let cmd = 'AT+'
        if (newApn) {
            cmd += `+CGDCONT=1,"${apnType || 'IPV4V6'}","${newApn}";`
        }
        if (prefNetwork) {
            cmd += `+QNWPREFCFG="mode_pref",${prefNetwork};`
        }
        if (nrMode) {
            cmd += `+QNWPREFCFG="nr5g_disable_mode",${nrMode}`
        }
        cmd = cmd.replace('AT++', 'AT+')

        if (cmd !== 'AT+') {
            await sendCommand(cmd)
            showCountdown(10)
        }
    }

    const currentBands = getCurrentBands()
    const currentLocked = getCurrentLockedBands()

    useEffect(() => {
        setSelectedBands(currentLocked)
    }, [networkMode, JSON.stringify(lockedBands)])

    return (
        <div className="network-page animate-fadeIn">
            {/* Band Locking Card */}
            <div className="card">
                <div className="card-header flex justify-between items-center">
                    <span>🔒 Khóa băng tần</span>
                    <select
                        className="form-control"
                        value={networkMode}
                        onChange={(e) => setNetworkMode(e.target.value)}
                        style={{ width: 'auto' }}
                    >
                        <option value="LTE">LTE (4G)</option>
                        <option value="NSA">NR5G-NSA</option>
                        <option value="SA">NR5G-SA</option>
                    </select>
                </div>
                <div className="card-body">
                    {loading ? (
                        <div className="flex justify-center items-center" style={{ padding: '2rem' }}>
                            <div className="spinner"></div>
                        </div>
                    ) : (
                        <div className="band-grid">
                            {currentBands.map(band => (
                                <label key={band} className="band-checkbox">
                                    <input
                                        type="checkbox"
                                        checked={selectedBands.includes(band)}
                                        onChange={() => handleBandToggle(band)}
                                    />
                                    <span className={`band-label ${currentLocked.includes(band) ? 'locked' : ''}`}>
                                        B{band}
                                    </span>
                                </label>
                            ))}
                        </div>
                    )}
                </div>
                <div className="card-footer flex justify-between items-center">
                    <div className="flex gap-sm">
                        <button className="btn btn-primary" onClick={lockBands} disabled={loading}>
                            Khóa băng tần
                        </button>
                        <button className="btn btn-secondary" onClick={() => setSelectedBands([])}>
                            Bỏ chọn tất cả
                        </button>
                        <button className="btn btn-danger" onClick={resetBands}>
                            Đặt lại
                        </button>
                    </div>
                    <span style={{ color: 'var(--text-muted)' }}>
                        Đang sử dụng: {activeBands}
                    </span>
                </div>
            </div>

            {/* Network Settings Card */}
            <div className="grid grid-2" style={{ marginTop: 'var(--space-lg)' }}>
                <div className="card">
                    <div className="card-header">⚙️ Cài đặt mạng</div>
                    <div className="card-body">
                        <div className="form-group">
                            <label className="form-label">APN</label>
                            <input
                                type="text"
                                className="form-control"
                                placeholder={apn || 'Nhập APN...'}
                                value={newApn}
                                onChange={(e) => setNewApn(e.target.value)}
                            />
                        </div>
                        <div className="form-group">
                            <label className="form-label">Loại APN</label>
                            <select className="form-control" value={apnType} onChange={(e) => setApnType(e.target.value)}>
                                <option value="">Chọn loại...</option>
                                <option value="IPV4">IPv4</option>
                                <option value="IPV6">IPv6</option>
                                <option value="IPV4V6">IPv4v6</option>
                            </select>
                        </div>
                        <div className="form-group">
                            <label className="form-label">Mạng ưa thích</label>
                            <select className="form-control" value={prefNetwork} onChange={(e) => setPrefNetwork(e.target.value)}>
                                <option value="">Chọn...</option>
                                <option value="AUTO">Tự động</option>
                                <option value="LTE">Chỉ LTE</option>
                                <option value="LTE:NR5G">NR5G-NSA</option>
                                <option value="NR5G">NR5G-SA</option>
                            </select>
                        </div>
                        <div className="form-group">
                            <label className="form-label">Chế độ NR5G</label>
                            <select className="form-control" value={nrMode} onChange={(e) => setNrMode(e.target.value)}>
                                <option value="">Chọn...</option>
                                <option value="0">Bật tất cả</option>
                                <option value="1">Tắt NR5G-SA</option>
                                <option value="2">Tắt NR5G-NSA</option>
                            </select>
                        </div>
                    </div>
                    <div className="card-footer">
                        <button className="btn btn-primary" onClick={saveSettings} disabled={loading}>
                            Lưu thay đổi
                        </button>
                    </div>
                </div>

                {/* SIM Selection */}
                <div className="card">
                    <div className="card-header">💳 Chọn SIM</div>
                    <div className="card-body">
                        <div className="sim-selector">
                            <label className={`sim-option ${currentSim === '1' ? 'active' : ''}`}>
                                <input
                                    type="radio"
                                    name="sim"
                                    value="1"
                                    checked={currentSim === '1'}
                                    onChange={(e) => setCurrentSim(e.target.value)}
                                />
                                <span>SIM 1</span>
                            </label>
                            <label className={`sim-option ${currentSim === '2' ? 'active' : ''}`}>
                                <input
                                    type="radio"
                                    name="sim"
                                    value="2"
                                    checked={currentSim === '2'}
                                    onChange={(e) => setCurrentSim(e.target.value)}
                                />
                                <span>SIM 2</span>
                            </label>
                        </div>
                        <p style={{ color: 'var(--text-muted)', marginTop: 'var(--space-md)', fontSize: '0.875rem' }}>
                            ⚠️ Thay đổi SIM sẽ khởi động lại thiết bị
                        </p>
                    </div>
                </div>
            </div>

            {/* Loading Modal */}
            {showModal && (
                <div className="modal-overlay">
                    <div className="modal">
                        <div className="flex flex-col items-center justify-center" style={{ padding: 'var(--space-lg)' }}>
                            <div className="spinner" style={{ marginBottom: 'var(--space-lg)' }}></div>
                            <h3>Đang khởi động lại mạng...</h3>
                            <p style={{ color: 'var(--text-muted)' }}>Vui lòng chờ {countdown} giây</p>
                        </div>
                    </div>
                </div>
            )}

            <style>{`
        .band-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(80px, 1fr));
          gap: var(--space-sm);
        }
        .band-checkbox {
          display: flex;
          align-items: center;
          gap: var(--space-xs);
          cursor: pointer;
        }
        .band-checkbox input {
          display: none;
        }
        .band-label {
          padding: var(--space-xs) var(--space-sm);
          border-radius: var(--radius-sm);
          background: var(--glass-bg);
          border: 1px solid var(--glass-border);
          font-size: 0.875rem;
          transition: all var(--transition-fast);
        }
        .band-checkbox input:checked + .band-label {
          background: var(--gradient-primary);
          color: white;
          border-color: transparent;
        }
        .band-label.locked {
          border-color: var(--accent-primary);
        }
        .sim-selector {
          display: flex;
          gap: var(--space-md);
        }
        .sim-option {
          flex: 1;
          padding: var(--space-lg);
          text-align: center;
          background: var(--glass-bg);
          border: 2px solid var(--glass-border);
          border-radius: var(--radius-lg);
          cursor: pointer;
          transition: all var(--transition-fast);
        }
        .sim-option input {
          display: none;
        }
        .sim-option.active {
          border-color: var(--accent-primary);
          background: rgba(99, 102, 241, 0.1);
        }
        .sim-option span {
          font-size: 1.25rem;
          font-weight: 600;
        }
      `}</style>
        </div>
    )
}

export default Network
