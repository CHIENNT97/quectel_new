import { useState, useEffect, useCallback } from 'react'
import { useATCommand } from '../hooks/useATCommand'

function DeviceInfo() {
    const { sendCommand, loading } = useATCommand()
    const [info, setInfo] = useState({
        manufacturer: '-',
        model: '-',
        firmware: '-',
        iccid: '-',
        imei: '-',
        wwanIpv4: '-',
        wwanIpv6: '-',
    })
    const [editingImei, setEditingImei] = useState(false)
    const [newImei, setNewImei] = useState('')
    const [showContributors, setShowContributors] = useState(false)

    const fetchDeviceInfo = useCallback(async () => {
        try {
            const data = await sendCommand('AT+CGMI;+CGMM;+CGMR;+QCCID;+CIMI;+CGSN;+QMAP="WWANIP"')
            const lines = data.split('\n')

            const newInfo = { ...info }

            // Parse manufacturer
            const manuLine = lines.find(l => !l.startsWith('+') && !l.includes('OK') && l.trim())
            if (manuLine) {
                newInfo.manufacturer = manuLine.trim()
            }

            // Parse model
            const modelLine = lines.find(l => l.includes('RM') || l.includes('RG'))
            if (modelLine) {
                newInfo.model = modelLine.trim()
            }

            // Parse ICCID
            const iccidLine = lines.find(l => l.includes('+QCCID:'))
            if (iccidLine) {
                newInfo.iccid = iccidLine.split(':')[1].trim()
            }

            // Parse IMEI  
            const imeiLine = lines.find(l => /^\d{15}$/.test(l.trim()))
            if (imeiLine) {
                newInfo.imei = imeiLine.trim()
            }

            // Parse WWAN IP
            const wwanLine = lines.find(l => l.includes('+QMAP: "WWANIP"'))
            if (wwanLine) {
                const match = wwanLine.match(/(\d+\.\d+\.\d+\.\d+)/)
                if (match) {
                    newInfo.wwanIpv4 = match[1]
                }
            }

            setInfo(newInfo)
        } catch (err) {
            console.error('Error fetching device info:', err)
        }
    }, [sendCommand])

    useEffect(() => {
        fetchDeviceInfo()
    }, [fetchDeviceInfo])

    const updateImei = async () => {
        if (newImei.length !== 15) {
            alert('IMEI phải có 15 chữ số')
            return
        }
        await sendCommand(`AT+EGMR=1,7,"${newImei}"`)
        setEditingImei(false)
        setNewImei('')
        fetchDeviceInfo()
    }

    const contributors = [
        { name: 'iamromulan', role: 'Tác giả chính' },
        { name: 'aesthesia', role: 'Đóng góp' },
        { name: 'snjzb', role: 'SMS Module' },
        { name: 'rbflurry', role: 'Đóng góp' },
    ]

    return (
        <div className="device-info-page animate-fadeIn">
            <div className="grid grid-2">
                {/* Device Information */}
                <div className="card">
                    <div className="card-header">📱 Thông tin thiết bị</div>
                    <div className="card-body">
                        {loading ? (
                            <div className="flex justify-center items-center" style={{ padding: '2rem' }}>
                                <div className="spinner"></div>
                            </div>
                        ) : (
                            <table>
                                <tbody>
                                    <tr>
                                        <th>Nhà sản xuất</th>
                                        <td>{info.manufacturer}</td>
                                    </tr>
                                    <tr>
                                        <th>Model</th>
                                        <td>{info.model}</td>
                                    </tr>
                                    <tr>
                                        <th>Firmware</th>
                                        <td>{info.firmware}</td>
                                    </tr>
                                    <tr>
                                        <th>ICCID</th>
                                        <td style={{ fontFamily: 'var(--font-mono)', fontSize: '0.875rem' }}>
                                            {info.iccid}
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>IMEI</th>
                                        <td>
                                            {editingImei ? (
                                                <div className="flex gap-sm">
                                                    <input
                                                        type="text"
                                                        className="form-control"
                                                        value={newImei}
                                                        onChange={(e) => setNewImei(e.target.value.replace(/\D/g, '').slice(0, 15))}
                                                        placeholder="Nhập IMEI mới"
                                                        style={{ width: '180px' }}
                                                    />
                                                    <button className="btn btn-primary btn-icon" onClick={updateImei}>✓</button>
                                                    <button className="btn btn-secondary btn-icon" onClick={() => setEditingImei(false)}>✕</button>
                                                </div>
                                            ) : (
                                                <div className="flex gap-sm items-center">
                                                    <span style={{ fontFamily: 'var(--font-mono)' }}>{info.imei}</span>
                                                    <button
                                                        className="btn btn-secondary btn-icon"
                                                        onClick={() => { setEditingImei(true); setNewImei(info.imei) }}
                                                        style={{ padding: '4px 8px', fontSize: '0.75rem' }}
                                                    >
                                                        ✏️
                                                    </button>
                                                </div>
                                            )}
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>WWAN IPv4</th>
                                        <td style={{ fontFamily: 'var(--font-mono)' }}>{info.wwanIpv4}</td>
                                    </tr>
                                    <tr>
                                        <th>WWAN IPv6</th>
                                        <td style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem' }}>{info.wwanIpv6}</td>
                                    </tr>
                                </tbody>
                            </table>
                        )}
                    </div>
                </div>

                {/* About */}
                <div className="card">
                    <div className="card-header">ℹ️ Thông tin ứng dụng</div>
                    <div className="card-body">
                        <div className="about-app">
                            <div className="app-logo">📱</div>
                            <h2 className="text-gradient">SimpleAdmin</h2>
                            <p style={{ color: 'var(--text-muted)' }}>Giao diện quản lý modem Quectel</p>
                            <div className="version-badge">
                                <span className="badge badge-info">v1.0.0 React</span>
                            </div>
                        </div>

                        <div style={{ marginTop: 'var(--space-xl)' }}>
                            <button
                                className="btn btn-secondary"
                                onClick={() => setShowContributors(true)}
                                style={{ width: '100%' }}
                            >
                                👥 Xem đóng góp
                            </button>
                        </div>
                    </div>
                    <div className="card-footer">
                        <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem', textAlign: 'center' }}>
                            <a
                                href="https://github.com/iamromulan/quectel-rgmii-toolkit"
                                target="_blank"
                                rel="noopener noreferrer"
                            >
                                🔗 GitHub Repository
                            </a>
                        </p>
                    </div>
                </div>
            </div>

            {/* Contributors Modal */}
            {showContributors && (
                <div className="modal-overlay" onClick={() => setShowContributors(false)}>
                    <div className="modal" onClick={e => e.stopPropagation()}>
                        <div className="modal-header">
                            <h3 className="modal-title">👥 Những người đóng góp</h3>
                        </div>
                        <div className="modal-body">
                            <div className="contributors-list">
                                {contributors.map((c, idx) => (
                                    <div key={idx} className="contributor-item">
                                        <div className="contributor-avatar">{c.name[0].toUpperCase()}</div>
                                        <div>
                                            <div className="contributor-name">{c.name}</div>
                                            <div className="contributor-role">{c.role}</div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                        <div className="modal-footer">
                            <button className="btn btn-primary" onClick={() => setShowContributors(false)}>
                                Đóng
                            </button>
                        </div>
                    </div>
                </div>
            )}

            <style>{`
        .about-app {
          text-align: center;
          padding: var(--space-lg) 0;
        }
        .app-logo {
          font-size: 4rem;
          margin-bottom: var(--space-md);
        }
        .about-app h2 {
          font-size: 1.75rem;
          margin-bottom: var(--space-sm);
        }
        .version-badge {
          margin-top: var(--space-md);
        }
        .contributors-list {
          display: flex;
          flex-direction: column;
          gap: var(--space-md);
        }
        .contributor-item {
          display: flex;
          align-items: center;
          gap: var(--space-md);
          padding: var(--space-sm);
          background: var(--glass-bg);
          border-radius: var(--radius-md);
        }
        .contributor-avatar {
          width: 40px;
          height: 40px;
          background: var(--gradient-primary);
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 600;
          color: white;
        }
        .contributor-name {
          font-weight: 600;
        }
        .contributor-role {
          font-size: 0.875rem;
          color: var(--text-muted);
        }
      `}</style>
        </div>
    )
}

export default DeviceInfo
