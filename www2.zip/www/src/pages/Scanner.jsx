import { useState, useCallback } from 'react'
import { useATCommand } from '../hooks/useATCommand'

function Scanner() {
    const { sendCommand, loading } = useATCommand()
    const [scanning, setScanning] = useState(false)
    const [results, setResults] = useState([])
    const [scanType, setScanType] = useState('LTE')

    const startScan = useCallback(async () => {
        setScanning(true)
        setResults([])

        try {
            // Cell scan command
            const cmd = scanType === 'NR5G'
                ? 'AT+QSCAN=3,1'
                : 'AT+QSCAN=1,1'

            const data = await sendCommand(cmd)
            const lines = data.split('\n').filter(l => l.includes('+QSCAN:'))

            const parsed = lines.map(line => {
                const parts = line.replace('+QSCAN:', '').split(',')
                return {
                    type: parts[0]?.replace(/"/g, '').trim(),
                    mcc: parts[1]?.trim(),
                    mnc: parts[2]?.trim(),
                    freq: parts[3]?.trim(),
                    pci: parts[4]?.trim(),
                    rsrp: parts[5]?.trim(),
                    rsrq: parts[6]?.trim(),
                    sinr: parts[7]?.trim(),
                }
            }).filter(r => r.type)

            setResults(parsed)
        } catch (err) {
            console.error('Scan error:', err)
        } finally {
            setScanning(false)
        }
    }, [sendCommand, scanType])

    const getSignalQuality = (rsrp) => {
        const val = parseInt(rsrp)
        if (isNaN(val)) return 'unknown'
        if (val >= -80) return 'excellent'
        if (val >= -90) return 'good'
        if (val >= -100) return 'fair'
        return 'poor'
    }

    return (
        <div className="scanner-page animate-fadeIn">
            <div className="card">
                <div className="card-header flex justify-between items-center">
                    <span>📡 Quét mạng di động</span>
                    <div className="flex gap-sm">
                        <select
                            className="form-control"
                            value={scanType}
                            onChange={(e) => setScanType(e.target.value)}
                            style={{ width: 'auto' }}
                        >
                            <option value="LTE">LTE (4G)</option>
                            <option value="NR5G">NR5G (5G)</option>
                        </select>
                        <button
                            className="btn btn-primary"
                            onClick={startScan}
                            disabled={scanning}
                        >
                            {scanning ? (
                                <>
                                    <span className="spinner" style={{ width: 16, height: 16 }}></span>
                                    Đang quét...
                                </>
                            ) : (
                                '🔍 Bắt đầu quét'
                            )}
                        </button>
                    </div>
                </div>
                <div className="card-body">
                    {scanning ? (
                        <div className="scan-loading">
                            <div className="scan-animation">
                                <div className="radar"></div>
                            </div>
                            <h3>Đang quét tín hiệu...</h3>
                            <p style={{ color: 'var(--text-muted)' }}>Quá trình này có thể mất vài phút</p>
                        </div>
                    ) : results.length > 0 ? (
                        <div className="results-table">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Loại</th>
                                        <th>MCC/MNC</th>
                                        <th>Tần số</th>
                                        <th>PCI</th>
                                        <th>RSRP</th>
                                        <th>RSRQ</th>
                                        <th>SINR</th>
                                        <th>Chất lượng</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {results.map((cell, idx) => (
                                        <tr key={idx}>
                                            <td><span className="badge badge-info">{cell.type}</span></td>
                                            <td>{cell.mcc}/{cell.mnc}</td>
                                            <td>{cell.freq}</td>
                                            <td>{cell.pci}</td>
                                            <td>{cell.rsrp} dBm</td>
                                            <td>{cell.rsrq} dB</td>
                                            <td>{cell.sinr} dB</td>
                                            <td>
                                                <span className={`badge badge-${getSignalQuality(cell.rsrp) === 'excellent' ? 'success' :
                                                        getSignalQuality(cell.rsrp) === 'good' ? 'info' :
                                                            getSignalQuality(cell.rsrp) === 'fair' ? 'warning' : 'danger'
                                                    }`}>
                                                    {getSignalQuality(cell.rsrp) === 'excellent' ? 'Tuyệt vời' :
                                                        getSignalQuality(cell.rsrp) === 'good' ? 'Tốt' :
                                                            getSignalQuality(cell.rsrp) === 'fair' ? 'Trung bình' : 'Yếu'}
                                                </span>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    ) : (
                        <div className="empty-state">
                            <div className="empty-icon">📡</div>
                            <h3>Chưa có kết quả</h3>
                            <p style={{ color: 'var(--text-muted)' }}>
                                Nhấn "Bắt đầu quét" để tìm kiếm các trạm phát sóng gần bạn
                            </p>
                        </div>
                    )}
                </div>
                <div className="card-footer">
                    <p style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>
                        💡 Quét mạng giúp bạn tìm các cell tower gần nhất và đánh giá chất lượng tín hiệu
                    </p>
                </div>
            </div>

            <style>{`
        .scan-loading {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 3rem;
          text-align: center;
        }
        .scan-animation {
          width: 120px;
          height: 120px;
          margin-bottom: 1.5rem;
          position: relative;
        }
        .radar {
          width: 100%;
          height: 100%;
          border: 3px solid var(--accent-primary);
          border-radius: 50%;
          position: relative;
          animation: pulse 1.5s ease-out infinite;
        }
        .radar::before {
          content: '';
          position: absolute;
          top: 50%;
          left: 50%;
          width: 60%;
          height: 60%;
          background: var(--gradient-primary);
          border-radius: 50%;
          transform: translate(-50%, -50%);
          animation: pulse 1.5s ease-out infinite 0.3s;
        }
        .radar::after {
          content: '';
          position: absolute;
          top: 50%;
          left: 50%;
          width: 30%;
          height: 30%;
          background: var(--accent-primary);
          border-radius: 50%;
          transform: translate(-50%, -50%);
        }
        @keyframes pulse {
          0% { transform: scale(0.8); opacity: 1; }
          100% { transform: scale(1.5); opacity: 0; }
        }
        .empty-state {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 3rem;
          text-align: center;
        }
        .empty-icon {
          font-size: 4rem;
          margin-bottom: 1rem;
          opacity: 0.5;
        }
        .results-table {
          overflow-x: auto;
        }
      `}</style>
        </div>
    )
}

export default Scanner
