import { useState, useEffect, useCallback } from 'react'
import { useATCommand } from '../hooks/useATCommand'

function SMS() {
    const { sendCommand, loading } = useATCommand()
    const [messages, setMessages] = useState([])
    const [senders, setSenders] = useState([])
    const [dates, setDates] = useState([])
    const [selectedMessages, setSelectedMessages] = useState([])
    const [phoneNumber, setPhoneNumber] = useState('')
    const [messageText, setMessageText] = useState('')
    const [sending, setSending] = useState(false)
    const [notification, setNotification] = useState(null)

    const convertHexToText = (hex) => {
        try {
            const bytes = new Uint8Array(hex.match(/.{1,2}/g).map(byte => parseInt(byte, 16)))
            return new TextDecoder('utf-16be').decode(bytes)
        } catch {
            return hex
        }
    }

    const fetchMessages = useCallback(async () => {
        try {
            const cmd = 'AT+CSMS=1;+CSDH=0;+CNMI=2,1,0,0,0;+CMGF=1;+CSCA?;+CSMP=17,167,0,8;+CPMS="ME","ME","ME";+CSCS="UCS2";+CMGL="ALL"'
            const data = await sendCommand(cmd)

            const lines = data.split('\n').filter(l => l.trim() !== 'OK' && l.trim() !== '')
            const cmglRegex = /^\s*\+CMGL:\s*(\d+),"[^"]*","([^"]*)"[^"]*,"([^"]*)"/gm

            const parsedMessages = []
            const parsedSenders = []
            const parsedDates = []

            let match
            while ((match = cmglRegex.exec(data)) !== null) {
                const senderHex = match[2]
                const sender = senderHex.length > 11 && (senderHex.startsWith('002B') || senderHex.startsWith('003'))
                    ? convertHexToText(senderHex)
                    : senderHex

                const dateStr = match[3].replace(/\+\d{2}$/, '')

                const startIdx = cmglRegex.lastIndex
                const endIdx = data.indexOf('+CMGL:', startIdx) !== -1
                    ? data.indexOf('+CMGL:', startIdx)
                    : data.length
                const msgHex = data.substring(startIdx, endIdx).trim()
                const messageContent = /^[0-9a-fA-F]+$/.test(msgHex) ? convertHexToText(msgHex) : msgHex

                parsedMessages.push({ text: messageContent, index: parseInt(match[1]) })
                parsedSenders.push(sender)
                parsedDates.push(dateStr)
            }

            setMessages(parsedMessages)
            setSenders(parsedSenders)
            setDates(parsedDates)
        } catch (err) {
            console.error('Error fetching SMS:', err)
        }
    }, [sendCommand])

    useEffect(() => {
        fetchMessages()
    }, [fetchMessages])

    const toggleSelect = (index) => {
        setSelectedMessages(prev =>
            prev.includes(index)
                ? prev.filter(i => i !== index)
                : [...prev, index]
        )
    }

    const selectAll = () => {
        if (selectedMessages.length === messages.length) {
            setSelectedMessages([])
        } else {
            setSelectedMessages(messages.map((_, i) => i))
        }
    }

    const deleteSelected = async () => {
        if (selectedMessages.length === 0) return

        if (selectedMessages.length === messages.length) {
            await sendCommand('AT+CMGD=,4')
        } else {
            const indices = selectedMessages.map(i => messages[i].index)
            const cmds = indices.map((idx, i) => i === 0 ? `AT+CMGD=${idx}` : `+CMGD=${idx}`).join(';')
            await sendCommand(cmds)
        }

        setSelectedMessages([])
        fetchMessages()
    }

    const encodeUCS2 = (text) => {
        let output = ''
        for (let i = 0; i < text.length; i++) {
            output += text.charCodeAt(i).toString(16).toUpperCase().padStart(4, '0')
        }
        return output
    }

    const sendSMS = async () => {
        if (!phoneNumber || !messageText) {
            showNotification('Vui lòng nhập số điện thoại và nội dung tin nhắn', 'warning')
            return
        }

        setSending(true)
        try {
            const encodedNumber = encodeUCS2(phoneNumber)
            const encodedMessage = encodeUCS2(messageText)

            const response = await fetch(`/cgi-bin/send_sms?number=${encodedNumber}&msg=${encodedMessage}&Command=0,1,1`)
            const result = await response.text()

            if (result.includes('+CMS ERROR')) {
                showNotification('Gửi tin nhắn thất bại!', 'danger')
            } else {
                showNotification('Gửi tin nhắn thành công!', 'success')
                setPhoneNumber('')
                setMessageText('')
            }
        } catch (err) {
            showNotification('Lỗi khi gửi tin nhắn', 'danger')
        } finally {
            setSending(false)
        }
    }

    const showNotification = (message, type) => {
        setNotification({ message, type })
        setTimeout(() => setNotification(null), 3000)
    }

    return (
        <div className="sms-page animate-fadeIn">
            {/* Inbox */}
            <div className="card">
                <div className="card-header flex justify-between items-center">
                    <span>📥 Hộp thư đến ({messages.length})</span>
                    <button
                        className="btn btn-secondary btn-icon"
                        onClick={fetchMessages}
                        disabled={loading}
                    >
                        🔄
                    </button>
                </div>
                <div className="card-body" style={{ maxHeight: '400px', overflowY: 'auto' }}>
                    {loading && messages.length === 0 ? (
                        <div className="flex justify-center items-center" style={{ padding: '2rem' }}>
                            <div className="spinner"></div>
                        </div>
                    ) : messages.length === 0 ? (
                        <div className="empty-state">
                            <div className="empty-icon">📭</div>
                            <p>Hộp thư trống</p>
                        </div>
                    ) : (
                        <div className="message-list">
                            {messages.map((msg, idx) => (
                                <div
                                    key={idx}
                                    className={`message-item ${selectedMessages.includes(idx) ? 'selected' : ''}`}
                                    onClick={() => toggleSelect(idx)}
                                >
                                    <div className="message-checkbox">
                                        <input
                                            type="checkbox"
                                            checked={selectedMessages.includes(idx)}
                                            onChange={() => { }}
                                        />
                                    </div>
                                    <div className="message-content">
                                        <div className="message-header">
                                            <span className="message-sender">{senders[idx]}</span>
                                            <span className="message-date">{dates[idx]}</span>
                                        </div>
                                        <div className="message-text">{msg.text}</div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
                {messages.length > 0 && (
                    <div className="card-footer flex justify-between items-center">
                        <label className="form-check">
                            <input
                                type="checkbox"
                                className="form-check-input"
                                checked={selectedMessages.length === messages.length}
                                onChange={selectAll}
                            />
                            <span>Chọn tất cả</span>
                        </label>
                        <div className="flex gap-sm">
                            <button
                                className="btn btn-danger"
                                onClick={deleteSelected}
                                disabled={selectedMessages.length === 0}
                            >
                                🗑️ Xóa ({selectedMessages.length})
                            </button>
                        </div>
                    </div>
                )}
            </div>

            {/* Send SMS */}
            <div className="card" style={{ marginTop: 'var(--space-lg)' }}>
                <div className="card-header">📤 Gửi tin nhắn</div>
                <div className="card-body">
                    <div className="form-group">
                        <label className="form-label">Số điện thoại người nhận</label>
                        <input
                            type="text"
                            className="form-control"
                            placeholder="+84..."
                            value={phoneNumber}
                            onChange={(e) => setPhoneNumber(e.target.value)}
                        />
                    </div>
                    <div className="form-group">
                        <label className="form-label">Nội dung tin nhắn</label>
                        <textarea
                            className="form-control"
                            rows="3"
                            placeholder="Nhập nội dung..."
                            value={messageText}
                            onChange={(e) => setMessageText(e.target.value)}
                        />
                    </div>
                    {notification && (
                        <div className={`notification ${notification.type}`}>
                            {notification.message}
                        </div>
                    )}
                    <button
                        className="btn btn-primary"
                        onClick={sendSMS}
                        disabled={sending}
                        style={{ width: '100%' }}
                    >
                        {sending ? 'Đang gửi...' : '📨 Gửi tin nhắn'}
                    </button>
                </div>
            </div>

            <style>{`
        .empty-state {
          text-align: center;
          padding: 2rem;
          color: var(--text-muted);
        }
        .empty-icon {
          font-size: 3rem;
          margin-bottom: 0.5rem;
        }
        .message-list {
          display: flex;
          flex-direction: column;
          gap: var(--space-sm);
        }
        .message-item {
          display: flex;
          gap: var(--space-md);
          padding: var(--space-md);
          background: var(--glass-bg);
          border: 1px solid var(--glass-border);
          border-radius: var(--radius-md);
          cursor: pointer;
          transition: all var(--transition-fast);
        }
        .message-item:hover {
          background: var(--bg-card-hover);
        }
        .message-item.selected {
          border-color: var(--accent-primary);
          background: rgba(99, 102, 241, 0.1);
        }
        .message-checkbox {
          padding-top: 2px;
        }
        .message-content {
          flex: 1;
        }
        .message-header {
          display: flex;
          justify-content: space-between;
          margin-bottom: var(--space-xs);
        }
        .message-sender {
          font-weight: 600;
          color: var(--text-primary);
        }
        .message-date {
          font-size: 0.75rem;
          color: var(--text-muted);
        }
        .message-text {
          color: var(--text-secondary);
          font-size: 0.9375rem;
          line-height: 1.5;
        }
        .notification {
          padding: var(--space-sm) var(--space-md);
          border-radius: var(--radius-md);
          margin-bottom: var(--space-md);
          animation: slideDown var(--transition-fast);
        }
        .notification.success {
          background: rgba(16, 185, 129, 0.1);
          color: var(--success);
          border: 1px solid var(--success);
        }
        .notification.danger {
          background: rgba(239, 68, 68, 0.1);
          color: var(--danger);
          border: 1px solid var(--danger);
        }
        .notification.warning {
          background: rgba(245, 158, 11, 0.1);
          color: var(--warning);
          border: 1px solid var(--warning);
        }
      `}</style>
        </div>
    )
}

export default SMS
