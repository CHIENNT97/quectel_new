import { useState } from 'react'
import { useDashboardData } from '../hooks/useATCommand'

function Dashboard() {
    const [refreshRate, setRefreshRate] = useState(5)
    const { data, loading, error, refresh } = useDashboardData(refreshRate)

    const getSignalClass = (percentage) => {
        if (percentage >= 60) return 'success'
        if (percentage >= 40) return 'warning'
        return 'danger'
    }

    return (
        <div className="dashboard animate-fadeIn">
            {/* Status Cards */}
            <div className="grid grid-4 stagger-children">
                <div className="card stat-card">
                    <div className="icon" style={{ background: 'linear-gradient(135deg, #f59e0b, #fbbf24)' }}>
                        🌡️
                    </div>
                    <div className="stat-value">{data.temperature}°C</div>
                    <div className="stat-label">Nhiệt độ</div>
                </div>

                <div className="card stat-card">
                    <div className="icon" style={{ background: 'linear-gradient(135deg, #8b5cf6, #a78bfa)' }}>
                        💳
                    </div>
                    <div className="stat-value" style={{ fontSize: '1.25rem' }}>{data.simStatus}</div>
                    <div className="stat-label">Trạng thái SIM</div>
                </div>

                <div className="card stat-card">
                    <div className="icon" style={{ background: 'linear-gradient(135deg, #06b6d4, #22d3ee)' }}>
                        📶
                    </div>
                    <div className="stat-value">{data.signalPercentage}%</div>
                    <div className="stat-label">Cường độ tín hiệu</div>
                </div>

                <div className="card stat-card">
                    <div className="icon" style={{ background: 'linear-gradient(135deg, #10b981, #34d399)' }}>
                        🌐
                    </div>
                    <div className="stat-value" style={{ fontSize: '1.1rem' }}>{data.internetConnectionStatus}</div>
                    <div className="stat-label">Kết nối Internet</div>
                </div>
            </div>

            {/* Info Cards */}
            <div className="grid grid-2" style={{ marginTop: 'var(--space-xl)' }}>
                {/* Network Information */}
                <div className="card">
                    <div className="card-header">
                        <span>📡 Thông tin mạng</span>
                        <span className="badge badge-info">{data.networkMode}</span>
                    </div>
                    <div className="card-body">
                        <table>
                            <tbody>
                                <tr>
                                    <th>SIM đang dùng</th>
                                    <td>{data.activeSim}</td>
                                </tr>
                                <tr>
                                    <th>Nhà mạng</th>
                                    <td>{data.networkProvider}</td>
                                </tr>
                                <tr>
                                    <th>MCC/MNC</th>
                                    <td>{data.mccmnc}</td>
                                </tr>
                                <tr>
                                    <th>APN</th>
                                    <td>{data.apn}</td>
                                </tr>
                                <tr>
                                    <th>Chế độ mạng</th>
                                    <td>{data.networkMode}</td>
                                </tr>
                                <tr>
                                    <th>Băng tần</th>
                                    <td>{data.bands}</td>
                                </tr>
                                <tr>
                                    <th>IPv4</th>
                                    <td style={{ fontFamily: 'var(--font-mono)', fontSize: '0.875rem' }}>{data.ipv4}</td>
                                </tr>
                                <tr>
                                    <th>Thời gian hoạt động</th>
                                    <td>{data.uptime}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div className="card-footer flex justify-between items-center">
                        <span style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>
                            Tự động cập nhật mỗi {refreshRate}s
                        </span>
                        <div className="flex gap-sm items-center">
                            <input
                                type="number"
                                min="3"
                                max="60"
                                value={refreshRate}
                                onChange={(e) => setRefreshRate(Math.max(3, parseInt(e.target.value) || 5))}
                                className="form-control"
                                style={{ width: '70px' }}
                            />
                            <button className="btn btn-secondary" onClick={refresh}>
                                🔄
                            </button>
                        </div>
                    </div>
                </div>

                {/* Signal Information */}
                <div className="card">
                    <div className="card-header">
                        <span>📊 Thông tin tín hiệu</span>
                        <span className={`badge badge-${getSignalClass(parseInt(data.signalPercentage))}`}>
                            {data.signalAssessment}
                        </span>
                    </div>
                    <div className="card-body">
                        <table>
                            <tbody>
                                <tr>
                                    <th>Đánh giá</th>
                                    <td>{data.signalAssessment}</td>
                                </tr>
                                <tr>
                                    <th>Thống kê</th>
                                    <td>{data.downloadStat} DL / {data.uploadStat} UL</td>
                                </tr>
                                <tr>
                                    <th>CSQ</th>
                                    <td>{data.csq}</td>
                                </tr>
                                <tr>
                                    <th>Cell ID</th>
                                    <td>{data.cellID}</td>
                                </tr>
                                <tr>
                                    <th>eNB ID</th>
                                    <td>{data.eNBID}</td>
                                </tr>
                                <tr>
                                    <th>TAC</th>
                                    <td>{data.tac}</td>
                                </tr>
                                {data.rsrpLTE !== '-' && (
                                    <tr>
                                        <th>RSRP (4G)</th>
                                        <td>
                                            <div className="progress">
                                                <div
                                                    className={`progress-bar ${getSignalClass(data.rsrpLTEPercentage)}`}
                                                    style={{ width: `${data.rsrpLTEPercentage}%` }}
                                                >
                                                    {data.rsrpLTE}
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                )}
                                {data.sinrLTE !== '-' && (
                                    <tr>
                                        <th>SINR (4G)</th>
                                        <td>
                                            <div className="progress">
                                                <div
                                                    className={`progress-bar ${getSignalClass(data.sinrLTEPercentage)}`}
                                                    style={{ width: `${data.sinrLTEPercentage}%` }}
                                                >
                                                    {data.sinrLTE}
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                    <div className="card-footer">
                        <span style={{ color: 'var(--text-muted)', fontSize: '0.875rem' }}>
                            Cập nhật lúc: {data.lastUpdate}
                        </span>
                    </div>
                </div>
            </div>

            {loading && !data.temperature && (
                <div className="loading-overlay">
                    <div className="spinner"></div>
                    <p>Đang tải dữ liệu...</p>
                </div>
            )}

            {error && (
                <div className="card" style={{ marginTop: 'var(--space-lg)', borderColor: 'var(--danger)' }}>
                    <div className="card-body" style={{ color: 'var(--danger)' }}>
                        ⚠️ Lỗi: {error}
                    </div>
                </div>
            )}
        </div>
    )
}

export default Dashboard
