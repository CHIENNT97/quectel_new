import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
    plugins: [react()],
    base: '/',
    build: {
        outDir: 'dist',
        emptyOutDir: true,
        rollupOptions: {
            output: {
                manualChunks: undefined,
            },
        },
    },
    server: {
        proxy: {
            '/cgi-bin': {
                target: 'http://192.168.225.1',
                changeOrigin: true,
            },
        },
    },
})
