// ========================================
// SimpleAdmin React Application
// ========================================

const { useState, useEffect, useCallback, createContext, useContext } = React;

// ========================================
// Theme Context
// ========================================
const ThemeContext = createContext();

const useTheme = () => useContext(ThemeContext);

const ThemeProvider = ({ children }) => {
    const [theme, setTheme] = useState(() => {
        return localStorage.getItem('theme') || 'dark';
    });

    useEffect(() => {
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('theme', theme);
    }, [theme]);

    const toggleTheme = () => {
        setTheme(prev => prev === 'dark' ? 'light' : 'dark');
    };

    return (
        <ThemeContext.Provider value={{ theme, toggleTheme }}>
            {children}
        </ThemeContext.Provider>
    );
};

// ========================================
// API Service
// ========================================
const api = {
    executeATCommand: async (cmd) => {
        const response = await fetch(`/cgi-bin/get_atcommand?atcmd=${encodeURIComponent(cmd)}`);
        return response.text();
    },

    getUptime: async () => {
        const response = await fetch('/cgi-bin/get_uptime');
        return response.text();
    },

    getTTLStatus: async () => {
        const response = await fetch('/cgi-bin/get_ttl_status');
        return response.text();
    },

    setTTL: async (ttl, iface) => {
        const response = await fetch(`/cgi-bin/set_ttl?ttl=${ttl}&iface=${iface}`);
        return response.text();
    },

    getWatchcatStatus: async () => {
        const response = await fetch('/cgi-bin/get_watchcat_status');
        return response.text();
    },

    sendSMS: async (to, message) => {
        const response = await fetch(`/cgi-bin/send_sms?to=${encodeURIComponent(to)}&message=${encodeURIComponent(message)}`);
        return response.text();
    },

    ping: async (host) => {
        const response = await fetch(`/cgi-bin/get_ping?host=${encodeURIComponent(host)}`);
        return response.text();
    }
};

// ========================================
// Icons
// ========================================
const Icons = {
    Dashboard: () => (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <rect x="3" y="3" width="7" height="7" rx="1" />
            <rect x="14" y="3" width="7" height="7" rx="1" />
            <rect x="14" y="14" width="7" height="7" rx="1" />
            <rect x="3" y="14" width="7" height="7" rx="1" />
        </svg>
    ),
    Network: () => (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="12" cy="12" r="10" />
            <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z" />
            <path d="M2 12h20" />
        </svg>
    ),
    Scanner: () => (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M3 7V5a2 2 0 0 1 2-2h2" />
            <path d="M17 3h2a2 2 0 0 1 2 2v2" />
            <path d="M21 17v2a2 2 0 0 1-2 2h-2" />
            <path d="M7 21H5a2 2 0 0 1-2-2v-2" />
            <path d="M8 12h8" />
        </svg>
    ),
    Settings: () => (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="12" cy="12" r="3" />
            <path d="M12 1v4M12 19v4M4.22 4.22l2.83 2.83M16.95 16.95l2.83 2.83M1 12h4M19 12h4M4.22 19.78l2.83-2.83M16.95 7.05l2.83-2.83" />
        </svg>
    ),
    SMS: () => (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
        </svg>
    ),
    Device: () => (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <rect x="5" y="2" width="14" height="20" rx="2" />
            <path d="M12 18h.01" />
        </svg>
    ),
    Temperature: () => (
        <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2a3.5 3.5 0 0 0-3.5 3.5v8.17a5 5 0 1 0 7 0V5.5A3.5 3.5 0 0 0 12 2zm0 18a3 3 0 0 1-1.5-5.6V5.5a1.5 1.5 0 0 1 3 0v8.9A3 3 0 0 1 12 20z" />
        </svg>
    ),
    Sim: () => (
        <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M18 2H8L4 6v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2zM8 8h2v2H8V8zm0 4h2v2H8v-2zm0 4h2v2H8v-2zm4-8h2v2h-2V8zm0 4h2v2h-2v-2zm0 4h2v2h-2v-2zm4-8h2v2h-2V8zm0 4h2v2h-2v-2zm0 4h2v2h-2v-2z" />
        </svg>
    ),
    Signal: () => (
        <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M3 17h2v4H3v-4zm4-5h2v9H7v-9zm4-4h2v13h-2V8zm4-5h2v18h-2V3z" />
        </svg>
    ),
    Cloud: () => (
        <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M19.35 10.04A7.49 7.49 0 0 0 12 4C9.11 4 6.6 5.64 5.35 8.04A5.994 5.994 0 0 0 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96z" />
        </svg>
    ),
    Moon: () => (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
        </svg>
    ),
    Sun: () => (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="12" cy="12" r="5" />
            <path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42" />
        </svg>
    ),
    Menu: () => (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M3 12h18M3 6h18M3 18h18" />
        </svg>
    ),
    Refresh: () => (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M23 4v6h-6M1 20v-6h6" />
            <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
        </svg>
    ),
    Check: () => (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
            <path d="M20 6L9 17l-5-5" />
        </svg>
    ),
    Send: () => (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z" />
        </svg>
    ),
    Trash: () => (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
        </svg>
    ),
    Terminal: () => (
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <polyline points="4 17 10 11 4 5" />
            <line x1="12" y1="19" x2="20" y2="19" />
        </svg>
    )
};

// ========================================
// Sidebar Component
// ========================================
const Sidebar = ({ currentPage, setCurrentPage, isOpen, setIsOpen }) => {
    const { theme, toggleTheme } = useTheme();

    const navItems = [
        { id: 'dashboard', label: 'Tổng Quan', icon: Icons.Dashboard },
        { id: 'network', label: 'Mạng', icon: Icons.Network },
        { id: 'scanner', label: 'Quét Sóng', icon: Icons.Scanner },
        { id: 'settings', label: 'Cài Đặt', icon: Icons.Settings },
        { id: 'sms', label: 'Tin Nhắn', icon: Icons.SMS },
        { id: 'device', label: 'Thiết Bị', icon: Icons.Device },
    ];

    return (
        <>
            <aside className={`sidebar ${isOpen ? 'open' : ''}`}>
                <div className="sidebar-header">
                    <a href="/" className="sidebar-logo">
                        <div className="sidebar-logo-icon">SA</div>
                        <span className="sidebar-logo-text">SimpleAdmin</span>
                    </a>
                </div>

                <nav className="sidebar-nav">
                    <div className="nav-section-title">ĐIỀU HƯỚNG</div>
                    {navItems.map(item => (
                        <a
                            key={item.id}
                            href="#"
                            className={`nav-link ${currentPage === item.id ? 'active' : ''}`}
                            onClick={(e) => {
                                e.preventDefault();
                                setCurrentPage(item.id);
                                setIsOpen(false);
                            }}
                        >
                            <span className="nav-link-icon">
                                <item.icon />
                            </span>
                            {item.label}
                        </a>
                    ))}
                </nav>

                <div className="sidebar-footer">
                    <div
                        className={`theme-toggle ${theme === 'dark' ? 'active' : ''}`}
                        onClick={toggleTheme}
                    >
                        <span className="theme-toggle-label">
                            {theme === 'dark' ? 'Chế Độ Tối' : 'Chế Độ Sáng'}
                        </span>
                        <div className="theme-toggle-switch"></div>
                    </div>
                </div>
            </aside>

            <div
                className={`overlay ${isOpen ? 'visible' : ''}`}
                onClick={() => setIsOpen(false)}
            />
        </>
    );
};

// ========================================
// Stat Card Component
// ========================================
const StatCard = ({ icon, value, label, type, tooltip }) => (
    <div
        className="stat-card fade-in"
        data-tooltip={tooltip}
    >
        <div className={`stat-icon ${type}`}>
            {icon}
        </div>
        <div className="stat-value">{value}</div>
        <div className="stat-label">{label}</div>
    </div>
);

// ========================================
// Progress Bar Component
// ========================================
const ProgressBar = ({ label, value, percentage, type = 'success' }) => {
    const getType = (pct) => {
        if (pct >= 60) return 'success';
        if (pct >= 40) return 'warning';
        return 'danger';
    };

    return (
        <div className="progress-container">
            <span className="progress-label">{label}</span>
            <div className="progress-bar">
                <div
                    className={`progress-fill ${type || getType(percentage)}`}
                    style={{ width: `${percentage}%` }}
                />
            </div>
            <span className="progress-value">{value}</span>
        </div>
    );
};

// ========================================
// Status Indicator Component
// ========================================
const StatusIndicator = ({ status, label }) => {
    const isOnline = status === 'connected' || status === 'online' || status === 'Đã kết nối';
    return (
        <span className="status-indicator">
            <span className={`status-dot ${isOnline ? 'online' : 'offline'}`}></span>
            {label}
        </span>
    );
};

// ========================================
// Loading Skeleton Component
// ========================================
const Skeleton = ({ type = 'text', count = 1 }) => {
    const items = Array(count).fill(0);
    return (
        <>
            {items.map((_, i) => (
                <div key={i} className={`skeleton skeleton-${type}`}></div>
            ))}
        </>
    );
};

// ========================================
// Card Component
// ========================================
const Card = ({ title, subtitle, children, footer }) => (
    <div className="card fade-in">
        {(title || subtitle) && (
            <div className="card-header">
                <div>
                    {title && <h3 className="card-title">{title}</h3>}
                    {subtitle && <p className="card-subtitle">{subtitle}</p>}
                </div>
            </div>
        )}
        {children}
        {footer && <div className="card-footer">{footer}</div>}
    </div>
);

// ========================================
// Data Table Component
// ========================================
const DataTable = ({ rows }) => (
    <table className="table">
        <tbody>
            {rows.map((row, i) => (
                <tr key={i}>
                    <th>{row.label}</th>
                    <td>{row.value}</td>
                </tr>
            ))}
        </tbody>
    </table>
);

// ========================================
// Signal Chart Component
// ========================================
const SignalChart = ({ rsrpHistory, rsrqHistory, sinrHistory }) => {
    const chartRef = React.useRef(null);
    const chartInstance = React.useRef(null);
    const { theme } = useTheme();

    useEffect(() => {
        if (!chartRef.current) return;

        const ctx = chartRef.current.getContext('2d');
        const gridColor = theme === 'dark' ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)';
        const textColor = theme === 'dark' ? '#a0a0b0' : '#4a4a5a';

        if (chartInstance.current) {
            chartInstance.current.destroy();
        }

        chartInstance.current = new Chart(ctx, {
            type: 'line',
            data: {
                labels: rsrpHistory.map((_, i) => i + 1),
                datasets: [
                    {
                        label: 'RSRP (dBm)',
                        data: rsrpHistory,
                        borderColor: '#00d4ff',
                        backgroundColor: 'rgba(0, 212, 255, 0.1)',
                        fill: true,
                        tension: 0.4,
                        pointRadius: 2,
                    },
                    {
                        label: 'RSRQ (dB)',
                        data: rsrqHistory,
                        borderColor: '#7c3aed',
                        backgroundColor: 'rgba(124, 58, 237, 0.1)',
                        fill: true,
                        tension: 0.4,
                        pointRadius: 2,
                    },
                    {
                        label: 'SINR (dB)',
                        data: sinrHistory,
                        borderColor: '#10b981',
                        backgroundColor: 'rgba(16, 185, 129, 0.1)',
                        fill: true,
                        tension: 0.4,
                        pointRadius: 2,
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: { intersect: false, mode: 'index' },
                plugins: {
                    legend: {
                        labels: { color: textColor, usePointStyle: true }
                    }
                },
                scales: {
                    x: {
                        grid: { color: gridColor },
                        ticks: { color: textColor }
                    },
                    y: {
                        grid: { color: gridColor },
                        ticks: { color: textColor }
                    }
                }
            }
        });

        return () => {
            if (chartInstance.current) {
                chartInstance.current.destroy();
            }
        };
    }, [rsrpHistory, rsrqHistory, sinrHistory, theme]);

    return (
        <div className="chart-container">
            <canvas ref={chartRef}></canvas>
        </div>
    );
};

// ========================================
// Traffic Chart Component (Gauge-style)
// ========================================
const TrafficChart = ({ downloadBytes, uploadBytes }) => {
    const chartRef = React.useRef(null);
    const chartInstance = React.useRef(null);
    const { theme } = useTheme();

    useEffect(() => {
        if (!chartRef.current) return;

        const ctx = chartRef.current.getContext('2d');
        const textColor = theme === 'dark' ? '#ffffff' : '#1a1a2e';

        if (chartInstance.current) {
            chartInstance.current.destroy();
        }

        chartInstance.current = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Tải xuống', 'Tải lên'],
                datasets: [{
                    data: [downloadBytes || 1, uploadBytes || 1],
                    backgroundColor: [
                        'rgba(0, 212, 255, 0.8)',
                        'rgba(124, 58, 237, 0.8)'
                    ],
                    borderColor: [
                        '#00d4ff',
                        '#7c3aed'
                    ],
                    borderWidth: 2,
                    hoverOffset: 10
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '60%',
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { color: textColor, usePointStyle: true, padding: 20 }
                    }
                }
            }
        });

        return () => {
            if (chartInstance.current) {
                chartInstance.current.destroy();
            }
        };
    }, [downloadBytes, uploadBytes, theme]);

    return (
        <div className="chart-container chart-small">
            <canvas ref={chartRef}></canvas>
        </div>
    );
};

// ========================================
// Signal Gauge Component
// ========================================
const SignalGauge = ({ value, max, label, color }) => {
    const percentage = Math.min(100, Math.max(0, (value / max) * 100));

    return (
        <div className="gauge">
            <svg viewBox="0 0 100 60" className="gauge-svg">
                <path
                    d="M 10 50 A 40 40 0 0 1 90 50"
                    fill="none"
                    stroke="var(--color-border)"
                    strokeWidth="8"
                    strokeLinecap="round"
                />
                <path
                    d="M 10 50 A 40 40 0 0 1 90 50"
                    fill="none"
                    stroke={color}
                    strokeWidth="8"
                    strokeLinecap="round"
                    strokeDasharray={`${percentage * 1.26} 126`}
                    style={{ transition: 'stroke-dasharray 0.5s ease' }}
                />
            </svg>
            <div className="gauge-value">{value}</div>
            <div className="gauge-label">{label}</div>
        </div>
    );
};

// ========================================
// Dashboard Page
// ========================================
const DashboardPage = () => {
    const [data, setData] = useState({
        temperature: '0',
        simStatus: 'Không có SIM',
        signalPercentage: '0',
        connectionStatus: 'Mất kết nối',
        activeSim: 'Không có SIM',
        networkProvider: 'Không xác định',
        mccmnc: '00000',
        apn: 'Không xác định',
        networkMode: 'Mất kết nối',
        bands: 'Không xác định',
        bandwidth: 'Không xác định',
        earfcns: '000',
        pci: '0',
        ipv4: '0.0.0.0',
        ipv6: '::',
        uptime: 'Không xác định',
        cellID: 'Không xác định',
        eNBID: 'Không xác định',
        tac: 'Không xác định',
        csq: '-',
        rsrpLTE: '-',
        rsrpNR: '-',
        rsrqLTE: '-',
        rsrqNR: '-',
        sinrLTE: '-',
        sinrNR: '-',
        rsrpLTEPct: 0,
        rsrpNRPct: 0,
        rsrqLTEPct: 0,
        rsrqNRPct: 0,
        sinrLTEPct: 0,
        sinrNRPct: 0,
        downloadStat: '0',
        uploadStat: '0',
        signalAssessment: 'Không xác định'
    });
    const [loading, setLoading] = useState(true);
    const [refreshRate, setRefreshRate] = useState(5);
    const [lastUpdate, setLastUpdate] = useState(new Date().toLocaleString());

    // Signal history for charts (keep last 20 readings)
    const [rsrpHistory, setRsrpHistory] = useState([]);
    const [rsrqHistory, setRsrqHistory] = useState([]);
    const [sinrHistory, setSinrHistory] = useState([]);
    const [downloadBytes, setDownloadBytes] = useState(0);
    const [uploadBytes, setUploadBytes] = useState(0);

    const bytesToSize = (bytes) => {
        const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
        if (bytes === 0) return '0 B';
        const i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
        return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
    };

    const calculateLteBw = (bw) => {
        const bwMap = { '0': 1.4, '1': 3, '2': 5, '3': 10, '4': 15, '5': 20 };
        return bwMap[bw] || bw;
    };

    const calculateNrBw = (bw) => {
        const bwMap = { '0': 5, '1': 10, '2': 15, '3': 20, '4': 25, '5': 30, '6': 40, '7': 50, '8': 60, '9': 80, '10': 100, '11': 200, '12': 400 };
        return bwMap[bw] || bw;
    };

    const rsrpToPercentage = (rsrp) => {
        const val = parseFloat(rsrp);
        if (isNaN(val)) return 0;
        return Math.max(0, Math.min(100, Math.round((val + 140) * 100 / 80)));
    };

    const rsrqToPercentage = (rsrq) => {
        const val = parseFloat(rsrq);
        if (isNaN(val)) return 0;
        return Math.max(0, Math.min(100, Math.round((val + 20) * 100 / 20)));
    };

    const sinrToPercentage = (sinr) => {
        const val = parseFloat(sinr);
        if (isNaN(val)) return 0;
        return Math.max(0, Math.min(100, Math.round((val + 10) * 100 / 40)));
    };

    const fetchData = useCallback(async () => {
        try {
            const atcmd = 'AT+QTEMP;+QUIMSLOT?;+QSPN;+CGCONTRDP=1;+QMAP="WWANIP";+QENG="servingcell";+QCAINFO;+QSIMSTAT?;+CSQ;+QGDNRCNT?;+QGDCNT?';
            const response = await api.executeATCommand(atcmd);

            if (response.includes('ERROR')) {
                console.error('AT command error');
                setLoading(false);
                return;
            }

            const lines = response.split('\n');
            const newData = { ...data };

            // Temperature
            try {
                const tempLine = lines.find(l => l.includes('+QTEMP:"cpuss-0-usr"')) ||
                    lines.find(l => l.includes('+QTEMP:"cpu0-a7-usr"'));
                if (tempLine) newData.temperature = tempLine.split(',')[1].replace(/"/g, '');
            } catch (e) { }

            // SIM Status
            try {
                const simLine = lines.find(l => l.includes('+QSIMSTAT:'));
                if (simLine) {
                    const status = simLine.split(' ')[1].split(',')[1];
                    newData.simStatus = status === '1' ? 'Hoạt động' : 'Không có SIM';
                }
            } catch (e) { }

            // Active SIM
            try {
                const slotLine = lines.find(l => l.includes('+QUIMSLOT:'));
                if (slotLine) {
                    const slot = slotLine.split(' ')[1].trim();
                    newData.activeSim = slot === '1' ? 'SIM 1' : slot === '2' ? 'SIM 2' : 'Không có SIM';
                }
            } catch (e) { }

            // Network Provider
            try {
                const spnLine = lines.find(l => l.includes('+QSPN:'));
                if (spnLine) {
                    const parts = spnLine.split(',');
                    let provider = parts[0].replace('+QSPN: ', '').replace(/"/g, '').replace(/ /g, '');
                    if (/^[0-9]+$/.test(provider)) provider = parts[2].replace(/"/g, '');
                    newData.networkProvider = provider;
                    newData.mccmnc = parts[4].replace(/"/g, '');
                }
            } catch (e) { }

            // APN
            try {
                const apnLine = lines.find(l => l.includes('+CGCONTRDP:'));
                if (apnLine) newData.apn = apnLine.split(',')[2].replace(/"/g, '');
            } catch (e) { }

            // Network Mode
            try {
                const servLine = lines.find(l => l.includes('+QENG: "servingcell"'));
                if (servLine) {
                    const mode = servLine.split(',')[2].replace(/"/g, '');
                    const duplex = servLine.split(',')[3].replace(/"/g, '');
                    if (mode === 'NR5G-SA') newData.networkMode = `5G SA ${duplex}`;
                    else if (mode === 'LTE') newData.networkMode = `4G LTE ${duplex}`;
                }
            } catch (e) {
                try {
                    const lteLine = lines.find(l => l.includes('+QENG: "LTE"'));
                    const nrLine = lines.find(l => l.includes('+QENG: "NR5G-NSA"'));
                    if (nrLine) newData.networkMode = '5G NSA';
                    else if (lteLine) {
                        const duplex = lteLine.split(',')[1].replace(/"/g, '');
                        newData.networkMode = `4G LTE ${duplex}`;
                    }
                } catch (e2) { }
            }

            // Bands
            try {
                const lteBands = lines.filter(l => l.includes('LTE BAND')).map(l => l.split(',')[3].replace(/"/g, ''));
                const nrBands = lines.filter(l => l.includes('NR5G BAND')).map(l => l.split(',')[3].replace(/"/g, ''));
                newData.bands = [...lteBands, ...nrBands].join(', ') || 'Không có';
            } catch (e) { }

            // IPv4/IPv6
            try {
                const ipv4Line = lines.find(l => l.includes('IPV4'));
                const ipv6Line = lines.find(l => l.includes('IPV6'));
                if (ipv4Line) newData.ipv4 = ipv4Line.split(',')[4].replace(/"/g, '');
                if (ipv6Line) newData.ipv6 = ipv6Line.split(',')[4].replace(/"/g, '');
            } catch (e) { }

            // Traffic Stats
            try {
                const nrCntLine = lines.find(l => l.includes('+QGDNRCNT:'));
                const cntLine = lines.find(l => l.includes('+QGDCNT:'));
                let dl = 0, ul = 0;
                if (nrCntLine) {
                    dl += parseInt(nrCntLine.replace('+QGDNRCNT: ', '').split(',')[0]) || 0;
                    ul += parseInt(nrCntLine.split(',')[1]) || 0;
                }
                if (cntLine) {
                    dl += parseInt(cntLine.split(',')[1]) || 0;
                    ul += parseInt(cntLine.replace('+QGDCNT: ', '').split(',')[0]) || 0;
                }
                newData.downloadStat = bytesToSize(dl);
                newData.uploadStat = bytesToSize(ul);
            } catch (e) { }

            // Signal Info
            try {
                const servLine = lines.find(l => l.includes('+QENG: "servingcell"'));
                if (servLine) {
                    const parts = servLine.split(',');
                    const mode = parts[2].replace(/"/g, '');

                    if (mode === 'NR5G-SA') {
                        newData.cellID = parts[6].replace(/"/g, '');
                        newData.tac = parseInt(parts[8], 16) + ` (${parts[8]})`;
                        newData.rsrpNR = parts[12] + ' dBm';
                        newData.rsrqNR = parts[13] + ' dB';
                        newData.sinrNR = parts[14] + ' dB';
                        newData.rsrpNRPct = rsrpToPercentage(parts[12]);
                        newData.rsrqNRPct = rsrqToPercentage(parts[13]);
                        newData.sinrNRPct = sinrToPercentage(parts[14]);
                    } else if (mode === 'LTE') {
                        newData.cellID = parts[8].replace(/"/g, '');
                        newData.tac = parseInt(parts[13], 16) + ` (${parts[13]})`;
                        newData.rsrpLTE = parts[14] + ' dBm';
                        newData.rsrqLTE = parts[15] + ' dB';
                        newData.sinrLTE = parts[16] + ' dB';
                        newData.rsrpLTEPct = rsrpToPercentage(parts[14]);
                        newData.rsrqLTEPct = rsrqToPercentage(parts[15]);
                        newData.sinrLTEPct = sinrToPercentage(parts[16]);
                    }

                    newData.eNBID = parseInt(newData.cellID.substring(0, newData.cellID.length - 2), 16) || 'Unknown';
                }
            } catch (e) { }

            // Signal Percentage & Assessment
            try {
                const avgPct = Math.max(
                    newData.rsrpLTEPct || 0,
                    newData.rsrpNRPct || 0,
                    newData.sinrLTEPct || 0,
                    newData.sinrNRPct || 0
                );
                newData.signalPercentage = avgPct;
                if (avgPct >= 70) newData.signalAssessment = 'Xuất sắc';
                else if (avgPct >= 50) newData.signalAssessment = 'Tốt';
                else if (avgPct >= 30) newData.signalAssessment = 'Trung bình';
                else newData.signalAssessment = 'Yếu';
            } catch (e) { }

            // Connection Status
            newData.connectionStatus = newData.networkMode !== 'Mất kết nối' ? 'Đã kết nối' : 'Mất kết nối';

            setData(newData);

            // Update signal history for charts (keep last 20 readings)
            const rsrpVal = parseFloat(newData.rsrpLTE) || parseFloat(newData.rsrpNR) || 0;
            const rsrqVal = parseFloat(newData.rsrqLTE) || parseFloat(newData.rsrqNR) || 0;
            const sinrVal = parseFloat(newData.sinrLTE) || parseFloat(newData.sinrNR) || 0;

            setRsrpHistory(prev => [...prev.slice(-19), rsrpVal]);
            setRsrqHistory(prev => [...prev.slice(-19), rsrqVal]);
            setSinrHistory(prev => [...prev.slice(-19), sinrVal]);

            // Store raw bytes for traffic chart
            setDownloadBytes(dl);
            setUploadBytes(ul);

            setLastUpdate(new Date().toLocaleString());
            setLoading(false);
        } catch (error) {
            console.error('Fetch error:', error);
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchData();
        const interval = setInterval(fetchData, refreshRate * 1000);
        return () => clearInterval(interval);
    }, [fetchData, refreshRate]);

    const networkRows = [
        { label: 'SIM đang dùng', value: data.activeSim },
        { label: 'Nhà mạng', value: data.networkProvider },
        { label: 'MCCMNC', value: data.mccmnc },
        { label: 'APN', value: data.apn },
        { label: 'Chế độ mạng', value: data.networkMode },
        { label: 'Băng tần', value: data.bands },
        { label: 'IPv4', value: data.ipv4 },
        { label: 'IPv6', value: data.ipv6 },
    ];

    const signalRows = [
        { label: 'Đánh giá', value: data.signalAssessment },
        { label: 'Lưu lượng', value: `${data.downloadStat} ↓ / ${data.uploadStat} ↑` },
        { label: 'Cell ID', value: data.cellID },
        { label: 'eNB ID', value: data.eNBID },
        { label: 'TAC', value: data.tac },
    ];

    if (loading) {
        return (
            <div className="loading">
                <div className="spinner"></div>
                <span>Đang tải dữ liệu...</span>
            </div>
        );
    }

    return (
        <>
            <div className="page-header">
                <h1 className="page-title">Tổng Quan</h1>
                <p className="page-subtitle">Theo dõi trạng thái thiết bị và thông tin mạng</p>
            </div>

            <div className="stats-grid">
                <StatCard
                    icon={<Icons.Temperature />}
                    value={`${data.temperature}°C`}
                    label="Nhiệt độ"
                    type="temperature"
                />
                <StatCard
                    icon={<Icons.Sim />}
                    value={data.simStatus}
                    label="Trạng thái SIM"
                    type="sim"
                />
                <StatCard
                    icon={<Icons.Signal />}
                    value={`${data.signalPercentage}%`}
                    label="Tín hiệu"
                    type="signal"
                />
                <StatCard
                    icon={<Icons.Cloud />}
                    value={data.connectionStatus}
                    label="Kết nối"
                    type="connection"
                />
            </div>

            <div className="info-grid">
                <Card
                    title="Thông Tin Mạng"
                    footer={
                        <div className="refresh-control">
                            <span className="refresh-label">Làm mới: {refreshRate}s</span>
                            <input
                                type="number"
                                className="form-input"
                                value={refreshRate}
                                min={3}
                                max={60}
                                onChange={(e) => setRefreshRate(Math.max(3, parseInt(e.target.value) || 3))}
                            />
                            <button className="btn btn-secondary btn-sm" onClick={fetchData}>
                                <Icons.Refresh />
                            </button>
                        </div>
                    }
                >
                    <DataTable rows={networkRows} />
                </Card>

                <Card
                    title="Thông Tin Tín Hiệu"
                    subtitle={`Cập nhật lúc: ${lastUpdate}`}
                >
                    <DataTable rows={signalRows} />

                    <div style={{ marginTop: '16px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
                        {data.rsrpLTE !== '-' && (
                            <ProgressBar label="RSRP 4G" value={data.rsrpLTE} percentage={data.rsrpLTEPct} />
                        )}
                        {data.rsrpNR !== '-' && (
                            <ProgressBar label="RSRP 5G" value={data.rsrpNR} percentage={data.rsrpNRPct} />
                        )}
                        {data.rsrqLTE !== '-' && (
                            <ProgressBar label="RSRQ 4G" value={data.rsrqLTE} percentage={data.rsrqLTEPct} />
                        )}
                        {data.rsrqNR !== '-' && (
                            <ProgressBar label="RSRQ 5G" value={data.rsrqNR} percentage={data.rsrqNRPct} />
                        )}
                        {data.sinrLTE !== '-' && (
                            <ProgressBar label="SINR 4G" value={data.sinrLTE} percentage={data.sinrLTEPct} />
                        )}
                        {data.sinrNR !== '-' && (
                            <ProgressBar label="SINR 5G" value={data.sinrNR} percentage={data.sinrNRPct} />
                        )}
                    </div>
                </Card>
            </div>

            {/* Charts Section */}
            <div className="charts-section">
                <Card title="Lịch Sử Tín Hiệu" subtitle="Biểu đồ RSRP, RSRQ, SINR theo thời gian">
                    {rsrpHistory.length > 1 ? (
                        <SignalChart
                            rsrpHistory={rsrpHistory}
                            rsrqHistory={rsrqHistory}
                            sinrHistory={sinrHistory}
                        />
                    ) : (
                        <div className="loading">
                            <span>Đang thu thập dữ liệu tín hiệu...</span>
                        </div>
                    )}
                </Card>

                <Card title="Phân Bố Lưu Lượng" subtitle="Tỷ lệ tải xuống và tải lên">
                    <TrafficChart
                        downloadBytes={downloadBytes}
                        uploadBytes={uploadBytes}
                    />
                </Card>
            </div>

            {/* Signal Gauges */}
            <div className="gauges-section">
                <Card title="Chất Lượng Tín Hiệu">
                    <div className="gauges-grid">
                        <SignalGauge
                            value={data.signalPercentage}
                            max={100}
                            label="Tổng thể"
                            color="#00d4ff"
                        />
                        <SignalGauge
                            value={data.rsrpLTEPct || data.rsrpNRPct || 0}
                            max={100}
                            label="RSRP"
                            color="#7c3aed"
                        />
                        <SignalGauge
                            value={data.sinrLTEPct || data.sinrNRPct || 0}
                            max={100}
                            label="SINR"
                            color="#10b981"
                        />
                    </div>
                </Card>
            </div>
        </>
    );
};

// ========================================
// Network Page
// ========================================
const NetworkPage = () => {
    const [bands, setBands] = useState([]);
    const [selectedBands, setSelectedBands] = useState(new Set());
    const [loading, setLoading] = useState(true);
    const [activeBands, setActiveBands] = useState('');
    const [pingHost, setPingHost] = useState('8.8.8.8');
    const [pingResult, setPingResult] = useState('');
    const [pingLoading, setPingLoading] = useState(false);

    const fetchBands = useCallback(async () => {
        try {
            const response = await api.executeATCommand('AT+QNWPREFCFG="lte_band"');
            const lines = response.split('\n');
            const bandLine = lines.find(l => l.includes('+QNWPREFCFG:'));
            if (bandLine) {
                const parts = bandLine.split(',');
                const availableBands = parts[1].split(':').map(b => `LTE B${b.trim()}`);
                setBands(availableBands);

                // Get active bands
                const activeResponse = await api.executeATCommand('AT+QCAINFO');
                const activeLines = activeResponse.split('\n');
                const lteBands = activeLines.filter(l => l.includes('LTE BAND')).map(l => l.split(',')[3].replace(/"/g, ''));
                const nrBands = activeLines.filter(l => l.includes('NR5G BAND')).map(l => l.split(',')[3].replace(/"/g, ''));
                setActiveBands([...lteBands, ...nrBands].join(', ') || 'Không có');
            }
            setLoading(false);
        } catch (error) {
            console.error('Error fetching bands:', error);
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        fetchBands();
    }, [fetchBands]);

    const toggleBand = (band) => {
        setSelectedBands(prev => {
            const next = new Set(prev);
            if (next.has(band)) next.delete(band);
            else next.add(band);
            return next;
        });
    };

    const applyBands = async () => {
        const bandNums = Array.from(selectedBands).map(b => b.replace('LTE B', '')).join(':');
        if (!bandNums) {
            alert('Vui lòng chọn ít nhất một băng tần');
            return;
        }
        try {
            await api.executeATCommand(`AT+QNWPREFCFG="lte_band",${bandNums}`);
            alert('Áp dụng băng tần thành công');
            fetchBands();
        } catch (error) {
            alert('Lỗi khi áp dụng băng tần');
        }
    };

    const runPing = async () => {
        setPingLoading(true);
        setPingResult('');
        try {
            const result = await api.ping(pingHost);
            setPingResult(result);
        } catch (error) {
            setPingResult('Ping thất bại');
        }
        setPingLoading(false);
    };

    return (
        <>
            <div className="page-header">
                <h1 className="page-title">Mạng</h1>
                <p className="page-subtitle">Quản lý khóa băng tần và tiện ích mạng</p>
            </div>

            <div className="info-grid">
                <Card
                    title="Khóa Băng Tần"
                    subtitle={`Băng tần đang dùng: ${activeBands}`}
                    footer={
                        <div style={{ display: 'flex', gap: '8px' }}>
                            <button className="btn btn-primary" onClick={applyBands}>
                                Áp dụng
                            </button>
                            <button className="btn btn-secondary" onClick={fetchBands}>
                                <Icons.Refresh /> Làm mới
                            </button>
                        </div>
                    }
                >
                    {loading ? (
                        <div className="loading">
                            <div className="spinner"></div>
                            <span>Đang tải băng tần...</span>
                        </div>
                    ) : (
                        <div className="checkbox-group">
                            {bands.map(band => (
                                <label
                                    key={band}
                                    className={`checkbox-item ${selectedBands.has(band) ? 'checked' : ''}`}
                                    onClick={() => toggleBand(band)}
                                >
                                    <div className="checkbox-check">
                                        <Icons.Check />
                                    </div>
                                    <span className="checkbox-label">{band}</span>
                                </label>
                            ))}
                        </div>
                    )}
                </Card>

                <Card title="Tiện Ích Mạng">
                    <div className="form-group">
                        <label className="form-label">Kiểm tra Ping</label>
                        <div style={{ display: 'flex', gap: '8px' }}>
                            <input
                                type="text"
                                className="form-input"
                                value={pingHost}
                                onChange={(e) => setPingHost(e.target.value)}
                                placeholder="8.8.8.8"
                            />
                            <button
                                className="btn btn-primary"
                                onClick={runPing}
                                disabled={pingLoading}
                            >
                                {pingLoading ? 'Đang ping...' : 'Ping'}
                            </button>
                        </div>
                    </div>
                    {pingResult && (
                        <div className="terminal" style={{ marginTop: '16px' }}>
                            <pre className="terminal-output">{pingResult}</pre>
                        </div>
                    )}
                </Card>
            </div>
        </>
    );
};

// ========================================
// Scanner Page  
// ========================================
const ScannerPage = () => {
    const [cells, setCells] = useState([]);
    const [loading, setLoading] = useState(false);
    const [scanMode, setScanMode] = useState('full');

    const startScan = async () => {
        setLoading(true);
        setCells([]);
        try {
            const response = await api.executeATCommand('AT+QSCAN=3');
            const lines = response.split('\n');
            const cellData = lines
                .filter(l => l.includes('+QSCAN:'))
                .map(l => {
                    const parts = l.replace('+QSCAN: ', '').split(',');
                    return {
                        network: parts[0]?.replace(/"/g, '') || '',
                        provider: parts[1]?.replace(/"/g, '') || '',
                        band: parts[2] || '',
                        earfcn: parts[3] || '',
                        pci: parts[4] || '',
                        rsrp: parts[5] || '',
                        sinr: parts[6] || ''
                    };
                });
            setCells(cellData);
        } catch (error) {
            console.error('Scan error:', error);
        }
        setLoading(false);
    };

    return (
        <>
            <div className="page-header">
                <h1 className="page-title">Quét Mạng</h1>
                <p className="page-subtitle">Quét tìm các trạm phát sóng khả dụng</p>
            </div>

            <Card
                title="Quét Trạm Phát Sóng"
                footer={
                    <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
                        <select
                            className="form-input form-select"
                            value={scanMode}
                            onChange={(e) => setScanMode(e.target.value)}
                            style={{ width: 'auto' }}
                        >
                            <option value="full">Quét đầy đủ</option>
                            <option value="quick">Quét nhanh</option>
                        </select>
                        <button
                            className="btn btn-primary"
                            onClick={startScan}
                            disabled={loading}
                        >
                            {loading ? 'Đang quét...' : 'Bắt đầu quét'}
                        </button>
                        <button
                            className="btn btn-secondary"
                            onClick={() => setCells([])}
                            disabled={loading || cells.length === 0}
                        >
                            Xóa
                        </button>
                    </div>
                }
            >
                {loading ? (
                    <div className="loading">
                        <div className="spinner"></div>
                        <span>Đang quét mạng... Có thể mất vài phút.</span>
                    </div>
                ) : cells.length === 0 ? (
                    <p style={{ color: 'var(--color-text-secondary)', textAlign: 'center', padding: '40px' }}>
                        Nhấn "Bắt đầu quét" để tìm kiếm các trạm khả dụng
                    </p>
                ) : (
                    <div style={{ overflowX: 'auto' }}>
                        <table className="table">
                            <thead>
                                <tr>
                                    <th>Mạng</th>
                                    <th>Nhà cung cấp</th>
                                    <th>Băng tần</th>
                                    <th>EARFCN</th>
                                    <th>PCI</th>
                                    <th>RSRP</th>
                                    <th>SINR</th>
                                </tr>
                            </thead>
                            <tbody>
                                {cells.map((cell, i) => (
                                    <tr key={i}>
                                        <td>{cell.network}</td>
                                        <td>{cell.provider}</td>
                                        <td>{cell.band}</td>
                                        <td>{cell.earfcn}</td>
                                        <td>{cell.pci}</td>
                                        <td>{cell.rsrp}</td>
                                        <td>{cell.sinr}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </Card>
        </>
    );
};

// ========================================
// Settings Page
// ========================================
const SettingsPage = () => {
    const [atCommand, setAtCommand] = useState('');
    const [atResponse, setAtResponse] = useState('');
    const [atLoading, setAtLoading] = useState(false);
    const [ttlValue, setTtlValue] = useState('64');
    const [ttlStatus, setTtlStatus] = useState('');

    const sendATCommand = async () => {
        if (!atCommand.trim()) return;
        setAtLoading(true);
        try {
            const response = await api.executeATCommand(atCommand);
            setAtResponse(prev => prev + `\n> ${atCommand}\n${response}`);
        } catch (error) {
            setAtResponse(prev => prev + `\n> ${atCommand}\nError: ${error.message}`);
        }
        setAtLoading(false);
        setAtCommand('');
    };

    const fetchTTLStatus = async () => {
        try {
            const response = await api.getTTLStatus();
            setTtlStatus(response);
        } catch (error) {
            console.error('TTL status error:', error);
        }
    };

    useEffect(() => {
        fetchTTLStatus();
    }, []);

    const applyTTL = async () => {
        try {
            await api.setTTL(ttlValue, 'rmnet_data0');
            alert('Áp dụng TTL thành công');
            fetchTTLStatus();
        } catch (error) {
            alert('Lỗi khi áp dụng TTL');
        }
    };

    return (
        <>
            <div className="page-header">
                <h1 className="page-title">Cài Đặt</h1>
                <p className="page-subtitle">Cấu hình thiết bị và chạy lệnh AT</p>
            </div>

            <div className="info-grid">
                <Card title="Terminal AT">
                    <div className="terminal">
                        <pre className="terminal-output">{atResponse || 'Sẵn sàng nhận lệnh...'}</pre>
                        <div className="terminal-input-line">
                            <span className="terminal-prompt">AT&gt;</span>
                            <input
                                type="text"
                                className="terminal-input"
                                value={atCommand}
                                onChange={(e) => setAtCommand(e.target.value)}
                                onKeyPress={(e) => e.key === 'Enter' && sendATCommand()}
                                placeholder="Nhập lệnh AT..."
                                disabled={atLoading}
                            />
                        </div>
                    </div>
                    <div style={{ marginTop: '16px', display: 'flex', gap: '8px' }}>
                        <button
                            className="btn btn-primary"
                            onClick={sendATCommand}
                            disabled={atLoading || !atCommand.trim()}
                        >
                            <Icons.Send /> Gửi
                        </button>
                        <button
                            className="btn btn-secondary"
                            onClick={() => setAtResponse('')}
                        >
                            Xóa
                        </button>
                    </div>
                </Card>

                <Card
                    title="Cài Đặt TTL"
                    subtitle={ttlStatus || 'Đang tải trạng thái...'}
                >
                    <div className="form-group">
                        <label className="form-label">Giá trị TTL</label>
                        <div style={{ display: 'flex', gap: '8px' }}>
                            <select
                                className="form-input form-select"
                                value={ttlValue}
                                onChange={(e) => setTtlValue(e.target.value)}
                            >
                                <option value="0">0 (Tắt)</option>
                                <option value="64">64</option>
                                <option value="65">65</option>
                                <option value="128">128</option>
                            </select>
                            <button className="btn btn-primary" onClick={applyTTL}>
                                Áp dụng TTL
                            </button>
                        </div>
                    </div>
                </Card>
            </div>
        </>
    );
};

// ========================================
// SMS Page
// ========================================
const SMSPage = () => {
    const [messages, setMessages] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedMessages, setSelectedMessages] = useState(new Set());
    const [newTo, setNewTo] = useState('');
    const [newMessage, setNewMessage] = useState('');
    const [sending, setSending] = useState(false);
    const [activeTab, setActiveTab] = useState('inbox');

    const fetchMessages = useCallback(async () => {
        setLoading(true);
        try {
            const response = await api.executeATCommand('AT+CMGF=1;+CMGL="ALL"');
            const lines = response.split('\n');
            const msgs = [];

            for (let i = 0; i < lines.length; i++) {
                if (lines[i].includes('+CMGL:')) {
                    const header = lines[i].replace('+CMGL: ', '');
                    const parts = header.split(',');
                    const index = parts[0];
                    const status = parts[1]?.replace(/"/g, '');
                    const sender = parts[2]?.replace(/"/g, '');
                    const dateTime = `${parts[3]?.replace(/"/g, '')} ${parts[4]?.replace(/"/g, '').split('+')[0]}`;
                    const text = lines[i + 1] || '';

                    msgs.push({ index, status, sender, dateTime, text });
                }
            }

            setMessages(msgs);
        } catch (error) {
            console.error('Error fetching SMS:', error);
        }
        setLoading(false);
    }, []);

    useEffect(() => {
        fetchMessages();
    }, [fetchMessages]);

    const toggleMessage = (index) => {
        setSelectedMessages(prev => {
            const next = new Set(prev);
            if (next.has(index)) next.delete(index);
            else next.add(index);
            return next;
        });
    };

    const deleteSelected = async () => {
        if (selectedMessages.size === 0) return;
        if (!confirm(`Xóa ${selectedMessages.size} tin nhắn?`)) return;

        for (const index of selectedMessages) {
            await api.executeATCommand(`AT+CMGD=${index}`);
        }
        setSelectedMessages(new Set());
        fetchMessages();
    };

    const sendSMS = async () => {
        if (!newTo.trim() || !newMessage.trim()) {
            alert('Vui lòng nhập người nhận và nội dung');
            return;
        }
        setSending(true);
        try {
            await api.sendSMS(newTo, newMessage);
            alert('Gửi SMS thành công');
            setNewTo('');
            setNewMessage('');
            setActiveTab('inbox');
            fetchMessages();
        } catch (error) {
            alert('Lỗi khi gửi SMS');
        }
        setSending(false);
    };

    return (
        <>
            <div className="page-header">
                <h1 className="page-title">Tin Nhắn</h1>
                <p className="page-subtitle">Quản lý tin nhắn SMS</p>
            </div>

            <Card>
                <div className="tabs">
                    <button
                        className={`tab-btn ${activeTab === 'inbox' ? 'active' : ''}`}
                        onClick={() => setActiveTab('inbox')}
                    >
                        Hộp thư ({messages.length})
                    </button>
                    <button
                        className={`tab-btn ${activeTab === 'compose' ? 'active' : ''}`}
                        onClick={() => setActiveTab('compose')}
                    >
                        Soạn tin
                    </button>
                </div>

                {activeTab === 'inbox' ? (
                    <>
                        {loading ? (
                            <div className="loading">
                                <div className="spinner"></div>
                                <span>Đang tải tin nhắn...</span>
                            </div>
                        ) : messages.length === 0 ? (
                            <p style={{ color: 'var(--color-text-secondary)', textAlign: 'center', padding: '40px' }}>
                                Hộp thư trống
                            </p>
                        ) : (
                            <div className="message-list">
                                {messages.map(msg => (
                                    <div
                                        key={msg.index}
                                        className="message-item"
                                        onClick={() => toggleMessage(msg.index)}
                                    >
                                        <div className="message-checkbox">
                                            <label className={`checkbox-item ${selectedMessages.has(msg.index) ? 'checked' : ''}`}>
                                                <div className="checkbox-check">
                                                    <Icons.Check />
                                                </div>
                                            </label>
                                        </div>
                                        <div className="message-content">
                                            <div className="message-sender">{msg.sender}</div>
                                            <div className="message-text">{msg.text}</div>
                                            <div className="message-time">{msg.dateTime}</div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                        <div style={{ marginTop: '16px', display: 'flex', gap: '8px' }}>
                            <button className="btn btn-secondary" onClick={fetchMessages}>
                                <Icons.Refresh /> Làm mới
                            </button>
                            {selectedMessages.size > 0 && (
                                <button className="btn btn-danger" onClick={deleteSelected}>
                                    <Icons.Trash /> Xóa đã chọn ({selectedMessages.size})
                                </button>
                            )}
                        </div>
                    </>
                ) : (
                    <>
                        <div className="form-group">
                            <label className="form-label">Gửi đến</label>
                            <input
                                type="text"
                                className="form-input"
                                value={newTo}
                                onChange={(e) => setNewTo(e.target.value)}
                                placeholder="Số điện thoại"
                            />
                        </div>
                        <div className="form-group">
                            <label className="form-label">Nội dung</label>
                            <textarea
                                className="form-input form-textarea"
                                value={newMessage}
                                onChange={(e) => setNewMessage(e.target.value)}
                                placeholder="Nhập nội dung tin nhắn..."
                            />
                        </div>
                        <button
                            className="btn btn-primary"
                            onClick={sendSMS}
                            disabled={sending}
                        >
                            <Icons.Send /> {sending ? 'Đang gửi...' : 'Gửi SMS'}
                        </button>
                    </>
                )}
            </Card>
        </>
    );
};

// ========================================
// Device Info Page
// ========================================
const DeviceInfoPage = () => {
    const [info, setInfo] = useState({
        manufacturer: 'Đang tải...',
        model: 'Đang tải...',
        revision: 'Đang tải...',
        imei: 'Đang tải...',
        iccid: 'Đang tải...',
        wwanIpv4: 'Đang tải...',
        wwanIpv6: 'Đang tải...'
    });
    const [loading, setLoading] = useState(true);
    const [newImei, setNewImei] = useState('');

    const fetchInfo = useCallback(async () => {
        try {
            const response = await api.executeATCommand('ATI;+CGSN;+QCCID;+CGPADDR');
            const lines = response.split('\n');

            const newInfo = { ...info };

            // Parse ATI response
            const mfgLine = lines.find(l => l.includes('Manufacturer:'));
            const modelLine = lines.find(l => l.includes('Model:'));
            const revLine = lines.find(l => l.includes('Revision:'));

            if (mfgLine) newInfo.manufacturer = mfgLine.replace('Manufacturer:', '').trim();
            if (modelLine) newInfo.model = modelLine.replace('Model:', '').trim();
            if (revLine) newInfo.revision = revLine.replace('Revision:', '').trim();

            // IMEI
            const imeiLine = lines.find(l => /^\d{15}$/.test(l.trim()));
            if (imeiLine) newInfo.imei = imeiLine.trim();

            // ICCID
            const iccidLine = lines.find(l => l.includes('+QCCID:'));
            if (iccidLine) newInfo.iccid = iccidLine.replace('+QCCID:', '').trim();

            // IPs
            const ipLine = lines.find(l => l.includes('+CGPADDR:'));
            if (ipLine) {
                const parts = ipLine.split(',');
                if (parts[1]) newInfo.wwanIpv4 = parts[1].replace(/"/g, '').trim();
                if (parts[2]) newInfo.wwanIpv6 = parts[2].replace(/"/g, '').trim();
            }

            setInfo(newInfo);
        } catch (error) {
            console.error('Error fetching device info:', error);
        }
        setLoading(false);
    }, []);

    useEffect(() => {
        fetchInfo();
    }, [fetchInfo]);

    const changeImei = async () => {
        if (!newImei.trim() || !/^\d{15}$/.test(newImei)) {
            alert('Vui lòng nhập IMEI hợp lệ (15 chữ số)');
            return;
        }
        if (!confirm('Bạn có chắc chắn muốn thay đổi IMEI không?')) return;

        try {
            await api.executeATCommand(`AT+EGMR=1,7,"${newImei}"`);
            alert('Đã thay đổi IMEI. Thiết bị sẽ khởi động lại.');
            setNewImei('');
            fetchInfo();
        } catch (error) {
            alert('Lỗi khi thay đổi IMEI');
        }
    };

    const infoRows = [
        { label: 'Nhà sản xuất', value: info.manufacturer },
        { label: 'Model', value: info.model },
        { label: 'Phiên bản', value: info.revision },
        { label: 'ICCID', value: info.iccid },
        { label: 'WWAN IPv4', value: info.wwanIpv4 },
        { label: 'WWAN IPv6', value: info.wwanIpv6 },
        { label: 'Phiên bản app', value: 'SimpleAdmin React v1.0' },
    ];

    return (
        <>
            <div className="page-header">
                <h1 className="page-title">Thông Tin Thiết Bị</h1>
                <p className="page-subtitle">Xem chi tiết thiết bị và thay đổi IMEI</p>
            </div>

            <div className="info-grid">
                <Card title="Chi Tiết Thiết Bị">
                    {loading ? (
                        <div className="loading">
                            <div className="spinner"></div>
                            <span>Đang tải thông tin...</span>
                        </div>
                    ) : (
                        <DataTable rows={infoRows} />
                    )}
                </Card>

                <Card title="Cài Đặt IMEI">
                    <div className="form-group">
                        <label className="form-label">IMEI hiện tại</label>
                        <input
                            type="text"
                            className="form-input"
                            value={info.imei}
                            readOnly
                        />
                    </div>
                    <div className="form-group">
                        <label className="form-label">IMEI mới</label>
                        <div style={{ display: 'flex', gap: '8px' }}>
                            <input
                                type="text"
                                className="form-input"
                                value={newImei}
                                onChange={(e) => setNewImei(e.target.value)}
                                placeholder="Nhập IMEI (15 số)"
                                maxLength={15}
                            />
                            <button className="btn btn-danger" onClick={changeImei}>
                                Thay đổi
                            </button>
                        </div>
                        <small style={{ color: 'var(--color-text-muted)', marginTop: '8px', display: 'block' }}>
                            Cảnh báo: Thay đổi IMEI sẽ khởi động lại thiết bị
                        </small>
                    </div>
                </Card>
            </div>
        </>
    );
};

// ========================================
// Main App Component
// ========================================
const App = () => {
    const [currentPage, setCurrentPage] = useState('dashboard');
    const [sidebarOpen, setSidebarOpen] = useState(false);

    const renderPage = () => {
        switch (currentPage) {
            case 'dashboard': return <DashboardPage />;
            case 'network': return <NetworkPage />;
            case 'scanner': return <ScannerPage />;
            case 'settings': return <SettingsPage />;
            case 'sms': return <SMSPage />;
            case 'device': return <DeviceInfoPage />;
            default: return <DashboardPage />;
        }
    };

    return (
        <ThemeProvider>
            <div className="app">
                <Sidebar
                    currentPage={currentPage}
                    setCurrentPage={setCurrentPage}
                    isOpen={sidebarOpen}
                    setIsOpen={setSidebarOpen}
                />

                <button
                    className="mobile-toggle"
                    onClick={() => setSidebarOpen(!sidebarOpen)}
                >
                    <Icons.Menu />
                </button>

                <main className="main-content">
                    {renderPage()}
                </main>
            </div>
        </ThemeProvider>
    );
};

// ========================================
// Render App
// ========================================
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
